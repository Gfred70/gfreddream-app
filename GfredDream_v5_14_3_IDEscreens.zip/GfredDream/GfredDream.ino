/**
 * ╔══════════════════════════════════════════════════════════════════════╗
 * ║         GfredDream — PPO2 Monitor rEvo CCR                           ║
 * ║         Version 5.14.3 — fix calib BLE + CALIBRER distant + reset 50/2%    ║
 * ║         Juillet 2026 — Fred & Claude                                 ║
 * ╠══════════════════════════════════════════════════════════════════════╣
 * ║  MATÉRIEL                                                            ║
 * ║  • ESP32-S3 Waveshare AMOLED 1.64" (CO5300 QSPI)                     ║
 * ║  • Écran physique 280×456 portrait → utilisé 456×280 paysage         ║
 * ║  • Framebuffer PSRAM + rotation logicielle 90° CCW                   ║
 * ║  • ADS1115 I2C @ 0x48 (SDA=IO47, SCL=IO48) — 2 cellules O2 diff.     ║
 * ║  • HUD LEDs : IO3 rouge / IO5 verte / IO6 orange                     ║
 * ║  • Reed calibration IO2 (NO) — maintien 1s, anti-redéclenchement     ║
 * ║  • Batterie ADC IO1 (pont 100k/100k, BAT_TRIM étalonné 1.030)        ║
 * ║  • LiPo 800mAh + TP4056 Type-C + Qi (QC3.0 9V obligatoire)           ║
 * ║  • PCB custom v1.2 52×52mm double face ENIG noir JLCPCB              ║
 * ╠══════════════════════════════════════════════════════════════════════╣
 * ║  ARCHITECTURE GRAPHIQUE                                              ║
 * ║  • 4 buffers PSRAM ~1MB total / 8MB dispo :                          ║
 * ║    framebuf     = dessin courant 456×280px                           ║
 * ║    portrait_buf = rotation 280×456 pour envoi écran                  ║
 * ║    textbuf      = pré-rendu splash / source fondu                    ║
 * ║    crossbuf     = source pour fondus enchaînés (E1→E2→E3 UNIQUEMENT) ║
 * ║  • canvas 456×60px = polices normales | canvasLarge 456×120 = géant  ║
 * ║  • 24 FPS (41ms/frame) — Arduino_Canvas plein écran INTERDIT (RAM!)  ║
 * ║  • Ancrages texte : fbTextLeft/Right/Center + FS = y BASELINE        ║
 * ║                     fbDrawTextTop / fbTextCenterTop = y TOP          ║
 * ╠══════════════════════════════════════════════════════════════════════╣
 * ║  CAPTEURS & CALCULS (v5.0)                                           ║
 * ║  • ADS1115 Wire brut, PGA ±0.256V, non-bloquant ~12Hz/cellule, EMA   ║
 * ║  • fabs() sur lectures (câblage inversé absorbé — cf. GfredCCR)      ║
 * ║  • PPO2 = mv/calib_mv × FiO2_ref × (mbar/1013) | divergence 0.15     ║
 * ║  • Calib : 36-64mV@O2pur × (FiO2/0.98) × (mbar/1013), moy. 3s        ║
 * ║  • NVS "gfred" : cal1/cal2/calfio2/calmbar (+fio2/mbar côté BLE)     ║
 * ║  • Verrou FiO2 ET pression : tout changement → calib invalidée       ║
 * ║  • Latch confiance : échec check air E3 → KO jusqu'à calib réussie   ║
 * ║  • Batterie : courbe LiPo réelle SOUS CHARGE (4.10V=100%, 3.60V=15%) ║
 * ║  • Verrou radio : boot <3.70V ou session <3.60V → WiFi/OTA/BLE OFF   ║
 * ║  • HUD : hudPulseOn() phase millis() — chronos MESURÉS sur le vrai   ║
 * ║    rEvodream (0.21 & 0.98, cycle réel 1.9s) ; autres zones estimées  ║
 * ╠══════════════════════════════════════════════════════════════════════╣
 * ║  NAVIGATION ÉCRANS                                                   ║
 * ║  E1 — Logo GfredDream animé          ✓ validé (fondu conservé)       ║
 * ║  E2 — Identification appareil        ✓ validé (fondu conservé)       ║
 * ║  E3 — Check cellules & batterie      ✓ validé (OK/ERR texte)         ║
 * ║  E4 — PPO2 principal plongée         ✓ validé (+ OTA/BTH bas écran)  ║
 * ║  CA1/CA2 — Calibration               ✓ validé (layout Shearwater)    ║
 * ║  AL_DEAD — Urgence 2 cellules KO     ✓ validé (OTA + reed recalib)   ║
 * ║  BT1–BT4 — Écrans Bluetooth          ABANDONNÉ (BTH bas écran suffit)║
 * ║  OTA1–OTA3 — Écrans mise à jour      ABANDONNÉ (OTA bas écran suffit)║
 * ║  Transitions : coupes sèches partout SAUF fondus E1→E2→E3            ║
 * ╠══════════════════════════════════════════════════════════════════════╣
 * ║  HISTORIQUE CONDENSÉ v4.x → v5.0 (détail : PASSATION_v5_0_0.md)      ║
 * ║  4.4.0  BLE NimBLE intégré (chat 3.1 BT) — UUIDs hex-only,           ║
 * ║         onWrite(p, NimBLEConnInfo&), setPower(int)                   ║
 * ║  4.5.x  Périmètre BLE réduit à l'usage réel : FiO2 + 2 luminosités ; ║
 * ║         CCR/Voting fixes ; FIO2_DEFAULT→0.98 ; ordre WiFi PUIS BLE   ║
 * ║         (radio RF partagée — bleInit APRÈS résolution WiFi !)        ║
 * ║  4.6.x  Télémétrie mV×10 + volts ; adv->setName() (v2.x ne l'émet    ║
 * ║         plus par défaut) ; race 1er connect (valeurs poussées dès    ║
 * ║         bleInit) ; luminosité écran → setBrightness() réel ;         ║
 * ║         E3 = plage AIR FIXE 8-13mV (pratique réelle : boot à l'air,  ║
 * ║         plaquette perso Fred) ; couleurs batterie ton médian         ║
 * ║  5.0.0  Version de clôture : audit complet (calculs/logique/         ║
 * ║         affichages), voting écran aligné sur le HUD (cellule valide  ║
 * ║         seule si 1 KO), nettoyage, commentaires didactiques          ║
 * ║  5.1.0  Voting = miroir exact du HUD physique : plus de cadre/fond   ║
 * ║         pulsé, seul le CHIFFRE change de couleur au rythme exact de  ║
 * ║         hudPulseOn() (vert continu, orange/rouge pendant l'ON du     ║
 * ║         pulse). AL_DEAD récupérable : reed maintenu 1s relance une   ║
 * ║         vraie calibration in-situ (même mécanisme que E4), sort      ║
 * ║         proprement vers E4 si au moins 1 cellule redevient valide —  ║
 * ║         plus besoin de rincer/rebooter pour une mauvaise manip banc. ║
 * ║  5.1.1  Voting REVU : le chiffre orange->vert à 0.21 était faux (pas ║
 * ║         de vert là-bas) et un chiffre qui flashe noir est illisible  ║
 * ║         sur les pulses courts — INVERSION : chiffre FIXE (vert dans  ║
 * ║         la fenêtre HUD, orange en dessous, rouge au-dessus, jamais   ║
 * ║         de flash dessus), le CADRE reprend le clignotement exact     ║
 * ║         (mêmes seuils/cadence hudPulseOn), invisible en zone silence.║
 * ║  5.2.0  Zone rapide <0.3/>1.65 REMESURÉE en vitesse réelle (le       ║
 * ║         ralenti du 11/07 était faux) : analyse pixel automatisée     ║
 * ║         (tracking anti-dérive) sur 2 clips indépendants, résultats   ║
 * ║         concordants au ms près — SALVE DE 7 PULSES (260 ON/241 OFF,  ║
 * ║         cycle 501ms) puis PAUSE ~660ms, super-cycle ~3.91s. Remplace ║
 * ║         l'ancienne hypothèse 3×(129/121ms)+pause 333ms (962ms).      ║
 * ║  5.3.0  3 zones de plus MESURÉES au caisson pression (montée >1.65   ║
 * ║         puis purge lente, PPO2 confirmé à l'écran du rEvodream) :    ║
 * ║         "2 pulses" 1.55-1.65 (2×984ms/écart 256ms/groupe 3.92s),      ║
 * ║         "1 pulse" 1.45-1.55 (988ms/3.783s), "très court" 1.0-1.25    ║
 * ║         (267ms/3.787s, ~100s stables). Symétrie orange/rouge         ║
 * ║         appliquée aux zones non mesurables (0.3-0.5, 0.5-0.7,        ║
 * ║         1.40-1.45) — jamais prise en défaut sur les zones vérifiées  ║
 * ║         des deux côtés. Seul 0.7-1.0 reste sur l'ancien ralenti      ║
 * ║         suspect (1.9s) — à revérifier en vitesse réelle.             ║
 * ║  5.4.0  Caisson étanchéifié, 10 clips filmés à l'air (0-7 bar),      ║
 * ║         chaque zone du chart directement ciblée et mesurée. Corrige  ║
 * ║         0.7-1.0 (320ms/1.9s du ralenti → 555ms/3.8s réel) et         ║
 * ║         confirme enfin 1.40-1.45 en direct (première mesure rouge    ║
 * ║         de cette zone, 265ms/3.8s — symétrie avec 1.0-1.25 validée). ║
 * ║         PLUS AUCUNE zone du chart posée par hypothèse : les 10       ║
 * ║         catégories ont chacune leur propre mesure vitesse réelle.    ║
 * ║  5.5.0  Alerte DIVERGENCE C1/C2 (seuil 0.15 bar, hystérésis 1.5s) :   ║
 * ║         Cell 1/Cell 2 restent affichées normalement (2 cellules =    ║
 * ║         pas de vote majoritaire possible, contrairement à un système ║
 * ║         3 cellules — jamais de valeur inventée), le chiffre voting   ║
 * ║         devient un mini-crâne clignotant (sprite AL_DEAD réutilisé   ║
 * ║         tel quel, sous-échantillonné ×4, zéro octet de flash en      ║
 * ║         plus), et le HUD physique s'éteint entièrement — décision    ║
 * ║         Fred : "effet sapin de Noël" à éviter, un HUD éteint est     ║
 * ║         un signal déjà bien identifié (réflexe → regarder l'écran).  ║
 * ║  5.6.0  VALIDÉ sur vrai matériel (test temporaire +0.3 bar sur Cell 2 ║
 * ║         puis retiré). Ajustements demandés : cadre orange retiré     ║
 * ║         pendant la divergence (cohérence avec le HUD physique déjà   ║
 * ║         éteint) ; crâne plus "frénétique" — cadence dédiée 300ms     ║
 * ║         (DIVERGENCE_BLINK_MS/ON) au lieu de réutiliser le rythme      ║
 * ║         calme d'AL_DEAD (situation active à surveiller, pas figée).  ║
 * ║  5.7.0  PRESSION DE CALIBRATION en millibars (lot 1/5 — firmware     ║
 * ║         seul, AUCUN changement visuel). Le manuel rEvodream P/P5     ║
 * ║         officiel gère bien l'altitude (section "Altitude calib.") :  ║
 * ║         sans sonde, il fait corriger la PPO2 à la main. Ici on entre ║
 * ║         directement les mbar — exactement ce que le Shearwater       ║
 * ║         affiche en "Pressure mBar / NOW" (vérifié sur le Predator    ║
 * ║         de Fred le 24/07 : NOW donne la VRAIE pression même quand    ║
 * ║         Altitude est réglé sur SeaLvl — SURF affiche 1013, NOW 978). ║
 * ║         CONFIG A (défaut) : 1013 → comportement identique à v5.6.0.  ║
 * ║         CONFIG B : NOW < 930 mbar → SW en Auto + mbar réel via PWA.  ║
 * ║         Diviseur 1013 (convention Shearwater), PAS 1000.             ║
 * ║         Verrou pression calqué sur le verrou FiO2 : la pression est  ║
 * ║         un paramètre DE LA CALIBRATION (elle n'entre dans la formule ║
 * ║         qu'au moment où on établit la sensibilité mV/bar), donc la   ║
 * ║         changer après coup invalide la calib et force une recalib.   ║
 * ║         Plage 36-64mV mise à l'échelle × (mbar/1013) : sans ça une   ║
 * ║         cellule saine serait refusée à tort en altitude (c'est le    ║
 * ║         piège du SeaLvl Shearwater, qui ne met PAS sa fenêtre à      ║
 * ║         l'échelle — déjà vécu par Fred : refus de calib sur cellule  ║
 * ║         un peu fatiguée + pression basse).                           ║
 * ║  5.8.0  LOT 2 — retours écran réel de Fred (24/07) :                 ║
 * ║         a) Échec de calibration affiché 10s au lieu de 2s            ║
 * ║            (CA2_HOLD_ERR_MS) : à FiO2 0.98, une calib lancée à l'air ║
 * ║            échoue en 2s, illisible. Le succès garde 2s.              ║
 * ║         b) Rappel PERMANENT sur E4 : "NO CAL" rouge (aucune cellule  ║
 * ║            calibrée) ou "CAL 1/2" orange (une seule), colonne        ║
 * ║            centrale y=92. Comblait un vrai trou : le ticker E3 est   ║
 * ║            inconditionnel et E3 ne dure que 5s — donc RIEN n'in-     ║
 * ║            diquait l'état de calibration pendant la plongée, alors   ║
 * ║            qu'une cellule non calibrée affiche 0.00 (plausible).     ║
 * ║            Fixe, pas clignotant : anti "sapin de Noël" (cf. 5.5.x).  ║
 * ║         c) Icône montagne vectorielle, visible en CONFIG B seule.    ║
 * ║            E4 y=116 (CCR descendu 130→150, proposition Fred) et      ║
 * ║            CA2 y=88 avec la valeur "### mb" — la pression est le     ║
 * ║            paramètre de cette calibration, elle est tracée avec.     ║
 * ║  5.8.1  FIX (test écran réel Fred, 24/07) : l'échec de calibration   ║
 * ║         n'apparaissait PAS sur E4. Cause : depuis la v4.x un échec   ║
 * ║         ne détruit pas la calibration précédente (sécurité voulue),  ║
 * ║         donc g_calib_cX restait > 0 et le test "== 0" ne voyait      ║
 * ║         rien. Ajout du drapeau de session g_cal_failed → "CAL KO"    ║
 * ║         rouge. 3 états : NO CAL / CAL KO / CAL 1/2.                  ║
 * ║         Montagne redessinée à DEUX pics décalés (croquis Fred),      ║
 * ║         34x20, pic avant en teinte atténuée pour la profondeur.      ║
 * ║  5.9.0  Verdict de calibration PAR CELLULE, à même son label (Fred,  ║
 * ║         24/07) : "OK" vert / "ERR" rouge à DROITE de Cell 1 et à     ║
 * ║         GAUCHE de Cell 2. Chaque marqueur est du côté de sa cellule  ║
 * ║         → impossible de se tromper de colonne. Objectif : continuer  ║
 * ║         en mode dégradé sur une seule cellule en sachant laquelle    ║
 * ║         est morte/débranchée. Remplace le message central v5.8.x.    ║
 * ║         PERSISTÉ en NVS (clés c1ko/c2ko) : couper le courant         ║
 * ║         n'efface plus l'avertissement — un échec laisse l'appareil   ║
 * ║         sur une calibration ANCIENNE, fait qui survit au reboot.     ║
 * ║         calibSave() devient INCONDITIONNEL : sous l'ancien "if       ║
 * ║         (c1_valid || c2_valid)", un DOUBLE échec n'écrivait rien.    ║
 * ║         Montagne + CCR recentrés (118/148) dans la bande libérée.    ║
 * ║  5.9.1  Marqueurs OK/ERR en FreeSansBold12pt — la police de CCR      ║
 * ║         (demande Fred). Mesure des labels conservée en 18pt : c'est  ║
 * ║         la largeur RÉELLE de "Cell 1"/"Cell 2" qui donne le point    ║
 * ║         de départ du marqueur, mesurer en 12pt le ferait chevaucher. ║
 * ║  5.9.2  Retours photo écran réel (Fred, 24/07) :                     ║
 * ║         a) "OK" passe en COL_DARK_GREEN — une info de NORMALITÉ ne    ║
 * ║            doit pas être l'élément le plus lumineux de l'écran.       ║
 * ║            Même vert que OTA/BTH : vocabulaire visuel cohérent.       ║
 * ║            Le "ERR" rouge reste plein — asymétrie voulue.             ║
 * ║         b) Montagne 34x20 → 42x24 via MTN_W/MTN_H (point de réglage   ║
 * ║            unique partagé par les 3 écrans). E4 recentré 116/150.     ║
 * ║         c) Montagne AJOUTÉE sur E3 (boot) : elle n'y était pas.       ║
 * ║            Colonne centrale y=75, entre titre et batterie.            ║
 * ║ 5.10.0  RÉFÉRENCE DE PRESSION VISIBLE EN PERMANENCE (Fred, 24/07).   ║
 * ║         Le principe "absence = normal" était faux : une absence est  ║
 * ║         indiscernable d'une panne (vieux firmware ? rendu raté ?).   ║
 * ║         Un symbole présent dit DEUX choses — quelle référence, ET    ║
 * ║         que le firmware sait où il en est. C'est ce que fait le      ║
 * ║         Shearwater avec son "SURF 1013" affiché en clair.            ║
 * ║         Config A → vaguelettes bleu discret | B → montagnes orange.  ║
 * ║         Contraste plat/relief, lisible sans texte.                   ║
 * ║         Les 4 écrans via drawPressureRef() — point d'entrée unique.  ║
 * ║         CA1 (stabilisation) ajouté : il manquait, alors que c'est    ║
 * ║         l'écran le plus important (10s pendant l'établissement de    ║
 * ║         la sensibilité mV/bar).                                      ║
 * ║         Valeur chiffrée sur E3/CA1/CA2 seulement — en plongée la     ║
 * ║         pression est figée depuis la calibration, l'icône suffit.    ║
 * ║ 5.11.0  PPO2 EN TIRETS si la calibration n'est pas exploitable —     ║
 * ║         idée Fred (24/07), meilleure que la mienne. Avant : la calib ║
 * ║         était EFFACÉE au boot et l'écran affichait "0.00" — chiffre  ║
 * ║         plausible, qui plus est dans la zone hypoxie, donc le HUD    ║
 * ║         hurlait une hypoxie alors que la vraie info est "je ne sais  ║
 * ║         pas". Des tirets ne mentent pas.                             ║
 * ║         Contrôle EN CONTINU (calRefMatch) et non plus au seul boot : ║
 * ║         supprime la fenêtre où une écriture BLE de pression donnait  ║
 * ║         une PPO2 fausse sans aucun signal jusqu'au redémarrage.      ║
 * ║         cal1/cal2 ne sont PLUS effacées → une écriture erronée est   ║
 * ║         RÉVERSIBLE (réécrire la valeur d'origine restaure la calib,  ║
 * ║         au lieu d'imposer un lavage O2 pour une faute de frappe).    ║
 * ║         HUD ÉTEINT si la calibration n'est pas exploitable (Fred :   ║
 * ║         "un truc qui va pas, HUD éteint, c'est tout"). Avant, une    ║
 * ║         PPO2 interne à 0.00 faisait clignoter l'orange rapide = le   ║
 * ║         HUD annonçait une HYPOXIE inexistante, erreur allant dans le ║
 * ║         mauvais sens (injection O2 inutile). Même sémantique que la  ║
 * ║         divergence : HUD éteint = regarde l'écran.                   ║
 * ║ 5.12.0  E3 NON BLOQUANT si la boucle contient de l'O2 (crash test    ║
 * ║         Fred 24/07 : calib O2, descente à PPO2 0.78, coupure/         ║
 * ║         rallumage → AL_DEAD alors que les cellules allaient bien).    ║
 * ║         Le check air suppose "boucle à l'air", précondition que le    ║
 * ║         firmware ne peut PAS vérifier ; il traduisait "supposition    ║
 * ║         violée" par "cellule morte" — erreur de catégorie.            ║
 * ║         Interlock rEvodream impossible : reed d'alim NC sur le rail,  ║
 * ║         coupure matérielle, le firmware n'est pas consulté.           ║
 * ║         Rattrapage : si les 2 cellules sont AU-DESSUS de 13mV, que la ║
 * ║         calib est exploitable, que les PPO2 recalculées tiennent sous ║
 * ║         PPO2 recalculées cohérentes et cellules d'accord (v5.12, retiré) ║
 * ║         → verdict "O2" orange, bandeau explicite, confiance MAINTENUE.║
 * ║         Asymétrie assumée : rattrapage vers le HAUT uniquement. Une   ║
 * ║         cellule en fin de vie lit BAS (limitation en courant), donc   ║
 * ║         trop bas reste une vraie panne. Corollaire discuté avec Fred  ║
 * ║         (projet trimix anoxique) : un rallumage sur boucle ANOXIQUE   ║
 * ║         donnera AL_DEAD — "2 cellules à 0mV" est indiscernable de     ║
 * ║         "2 cellules mortes". Sortie par recalibration au reed.        ║
 * ║ 5.12.1  FIX du plafond de la 5.12.0 (1.10 → 1.70). Il supposait un    ║
 * ║         boot EN SURFACE, or l'appareil n'a pas de capteur de          ║
 * ║         profondeur : un reed d'alim effleuré sous l'eau provoque      ║
 * ║         coupure + redémarrage EN PLONGÉE, boucle au setpoint 1.3 →    ║
 * ║         1.30 > 1.10 → AL_DEAD à 40m, au pire moment possible.         ║
 * ║         Le plafond est un test d'ABSURDITÉ, pas un test de surface :  ║
 * ║         il doit valoir à toute profondeur. Le vrai discriminant reste ║
 * ║         l'accord inter-cellules, indépendant de la profondeur.        ║
 * ║ 5.13.0  GROS NETTOYAGE — retour à un usage SIMPLE (décision Fred      ║
 * ║         24/07 : on s'était laissé embarquer dans une complexité de    ║
 * ║         procédure incompatible avec l'usage). E3 devient PUREMENT     ║
 * ║         INFORMATIF : il MESURE et AFFICHE, il ne bloque plus rien,    ║
 * ║         comme le Shearwater. Supprimés : latch de confiance, rattra-  ║
 * ║         page richLoop, plafond BOOT_PPO2_MAX, test d'accord au boot,  ║
 * ║         idée de paramètre diluant (inutile : E3 affiche la PPO2, Fred ║
 * ║         lit lui-même si ça colle). cellCompute() ne dépend plus que   ║
 * ║         de la plage vitale 2-95mV — une seule chose vérifiable.       ║
 * ║         Rallumage en cours de session : la PPO2 revient toujours sur  ║
 * ║         la dernière calibration. AL_DEAD réservé au seul cas matériel ║
 * ║         (2 cellules hors plage vitale). ~60 lignes en moins, plus     ║
 * ║         aucun scénario de rallumage à documenter.                     ║
 * ║         E3 : code couleur par cellule VERT (air) / ORANGE (O2-nitrox  ║
 * ║         dans la boucle, >0.30) / ROUGE (<0.16 non respirable, ou pas  ║
 * ║         de signal). Ligne du bas = PPO2 mesurée (ou mV si pas calib). ║
 * ║         + Flash de TRANSITION : 3 impulsions des 3 LED quand une      ║
 * ║         cellule change d'état OK↔ERR (bloquant ~600ms, 2 sens).       ║
 * ║         + Cellules O2 : le vieillissement se voit BAS (current-limit, ║
 * ║         cf. recherche) → aucun seuil mV haut, divergence + check 1.60.║
 * ╠══════════════════════════════════════════════════════════════════════╣
 * ║  RESTE À FAIRE (prochain chat — PASSATION_v5_6_0.md)                 ║
 * ║  [x] HUD : chart complet mesuré en vitesse réelle — TERMINÉ v5.4.0   ║
 * ║  [x] Voting : alerte divergence — TERMINÉ v5.6.0, VALIDÉ sur vrai    ║
 * ║      matériel (mini-crâne 300ms, cadre retiré, HUD off, position OK) ║
 * ║  [x] Pression/altitude : firmware — TERMINÉ v5.7.0 (lot 1)           ║
 * ║  [x] Lot 2 : montagne CA2+E4, rappel calib, hold erreur — v5.8.0     ║
 * ║  [x] Lot 3 : PWA carte pression + fix télémétrie calib BLE — v5.14.3 ║
 * ║  [x] Lot 4 : bouton calibrage BLE (ARM 0x5A / GO 0xA5, 000D) v5.14.3 ║
 * ║  [x] Fix v5.14.3 : reset n'appliquait pas réellement l'écran à 50%   ║
 * ║      (g_params_changed écrasé par bleParamsSave() dans la même       ║
 * ║      fonction) + caractéristiques BLE brit/hud non resync après reset║
 * ║  [x] Fix v5.14.3 : bouton CALIBRER BLE muet pendant AL_DEAD (while   ║
 * ║      bloquant séparé de loop()) — inutile dans le seul cas où Fred   ║
 * ║      en a vraiment besoin. Ajouté dans showScreenALDEAD() aussi.     ║
 * ║  [x] Fix v5.14.3 : caractéristique BLE FiO2 pas resync après reset   ║
 * ║      (même bug que brit/hud, oublié pour celle-là) — la PWA          ║
 * ║      affichait l'ancien FiO2 au lieu de 0.98 après reset             ║
 * ║  [ ] Lot 5 : Δ% vs calibration précédente sur CA2                    ║
 * ║  [ ] Batterie : 4.02V affiché à pleine charge (attendu ~4.2V) —      ║
 * ║      vérifier terminaison TP4056 / relaxation / BAT_TRIM — Fred doit ║
 * ║      ouvrir le boîtier, pas pour tout de suite                       ║
 * ╚══════════════════════════════════════════════════════════════════════╝
 */
// ═══════════════════════════════════════════════════════════════════════
//  BIBLIOTHÈQUES
// ═══════════════════════════════════════════════════════════════════════
#include <Arduino_GFX_Library.h>      // Driver CO5300 QSPI + Arduino_Canvas
#include <Adafruit_GFX.h>             // Polices vectorielles FreeSans/FreeSerif
#include <WiFi.h>
#include <ESPmDNS.h>                  // Découverte réseau pour OTA Arduino IDE
#include <WiFiUdp.h>                  // Requis pour ArduinoOTA
#include <ArduinoOTA.h>
#include <Wire.h>                     // I2C → ADS1115
#include <Preferences.h>              // NVS → calibration persistée

// Polices — titres italiques (FreeSerif) et corps (FreeSans)
#include <Fonts/FreeSansBold24pt7b.h>
#include <Fonts/FreeSansBold18pt7b.h>
#include <Fonts/FreeSansBold12pt7b.h>
#include <Fonts/FreeSans9pt7b.h>
#include <Fonts/FreeSerifBoldItalic24pt7b.h>
#include <Fonts/FreeSerifBoldItalic18pt7b.h>
#include <Fonts/FreeSerifBoldItalic12pt7b.h>
#include <Fonts/FreeSerifBoldItalic9pt7b.h>

// Ressources graphiques en PROGMEM (Flash)
#include "credentials.h"    // WiFi SSID/password + OTA hostname/password
#include "splash_bg.h"      // Fond plongeur CCR 456×280 RGB565 (E1)
#include "splash_fond.h"    // Fond sous-marin 456×280 RGB565 (E2/E3)
#include "splash_logo.h"    // Logo GfredDream + canal alpha (E1)
#include "sprite_dead.h"    // Crâne + tibias croisés 220×220px + alpha (AL_DEAD)
#include "gfred_params.h"   // Paramètres BLE/NVS partagés (chat 3.1 BT, périmètre affiné depuis)
#include "ble_service.h"    // Service GATT NimBLE — 7 caractéristiques

// ═══════════════════════════════════════════════════════════════════════
//  CONFIGURATION MATÉRIELLE
// ═══════════════════════════════════════════════════════════════════════

// Broches display CO5300 QSPI (câblage interne module Waveshare)
#define LCD_CS   9
#define LCD_SCLK 10
#define LCD_D0   11
#define LCD_D1   12
#define LCD_D2   13
#define LCD_D3   14
#define LCD_RST  21

// Dimensions écran logique paysage et physique portrait
#define PHYS_W  280   // largeur physique portrait
#define PHYS_H  456   // hauteur physique portrait
#define LAND_W  456   // largeur framebuffer paysage
#define LAND_H  280   // hauteur framebuffer paysage

// Broches PCB custom GfredDream v1.2
#define PIN_LED_RED    3    // HUD LED rouge  (hypoxie / hyperoxie)
#define PIN_LED_GREEN  5    // HUD LED verte  (zone normale)
#define PIN_LED_ORANGE 6    // HUD LED orange (alerte bas)
#define PIN_REED_CALIB 2    // Reed switch NO INPUT_PULLUP → calibration
#define PIN_BAT_ADC    1    // ADC batterie via pont 100kΩ/100kΩ
#define PIN_I2C_SDA   47   // I2C SDA → ADS1115 @ 0x48
#define PIN_I2C_SCL   48   // I2C SCL

// Position logo splash sur fond plongeur
#define LOGO_FINAL_X  ((LAND_W - LOGO_W) / 2)
#define LOGO_FINAL_Y  (LAND_H - LOGO_H + 2)

// ═══════════════════════════════════════════════════════════════════════
//  COULEURS RGB565
// ═══════════════════════════════════════════════════════════════════════
#define COL_BLACK      0x0000
#define COL_WHITE      0xFFFF
#define COL_GREEN      0x07E0
#define COL_RED        0xF800
#define COL_YELLOW     0xFFE0
#define COL_ORANGE     0xFD20
#define COL_DARK_GREY  0x39E7
#define COL_LIGHT_GREY 0xC618
#define COL_CYAN       0x07FF
#define COL_BLUE_DARK  0x035F   // couleur Cell 1/2 et mV
#define COL_MID_GREY   0x31A6   // gris sombre — indicateurs radios presque invisibles (v4.2.9)
#define COL_DARK_GREEN 0x01E0   // vert très foncé — radio connectée (assombri v4.2.9)
#define COL_DARK_RED   0x4000   // rouge très foncé — verrou tension (assombri v4.2.9)
// Couleurs batterie dédiées — v4.6.6 : les COL_DARK_* ci-dessus (partagées
// avec OTA/BTH, volontairement "quasi invisibles") étaient trop sombres une
// fois testées sur le vrai écran — plus assez visibles du tout (retour Fred
// 13/07). Celles-ci sont un ton intermédiaire, dédiées UNIQUEMENT à la
// batterie — ne jamais les fusionner avec COL_DARK_GREEN/RED (qui doivent
// rester discrets pour OTA/BTH).
#define COL_BATT_GREEN  0x0480  // vert moyen — ~57% de COL_GREEN
#define COL_BATT_ORANGE 0x9300  // orange moyen — ~58% de COL_ORANGE
#define COL_BATT_RED    0x9000  // rouge moyen — ~58% de COL_RED

// ═══════════════════════════════════════════════════════════════════════
//  PARAMÈTRES CELLULES O2
// ═══════════════════════════════════════════════════════════════════════

// Plage mV valide pour vérification à l'air (21% O2) en E3
#define CELL_MV_MIN   8.0f
#define CELL_MV_MAX  13.0f

// v5.13.0 — seuils PPO2 pour le CODE COULEUR de l'écran E3 (informatif).
//   PPO2_BREATHABLE_MIN : sous 0.16 bar, mélange non respirable en surface
//     (seuil donné par Fred — en plongée hypoxique on ponte sur un gaz
//     externe en profondeur, jamais respiré au démarrage) → rouge.
//   AIR_PPO2_MAX : au-dessus, ce n'est plus de l'air (O2/nitrox dans la
//     boucle) → orange. 0.30 laisse la marge météo + tolérance cellule
//     au-dessus des ~0.21 nominaux de l'air.
#define PPO2_BREATHABLE_MIN 0.16f
#define AIR_PPO2_MAX        0.30f

// ── ADS1115 — vraies lectures (v4.0.0) ────────────────────────────────
#define ADS_ADDR        0x48     // adresse I2C (ADDR → GND)
#define ADS_REG_CONV    0x00     // registre conversion (résultat signé 16 bits)
#define ADS_REG_CONFIG  0x01     // registre configuration
// PGA ±0.256V (gain 16) → LSB = 7.8125 µV. Plage largement suffisante :
// ~10mV à l'air, ~47mV à l'O2 pur, ~80mV à PPO2 1.6 — pleine échelle ±256mV
#define ADS_LSB_MV      0.0078125f
// Config de base : OS=1 (start single), PGA=101 (±0.256V), MODE=1 (single-shot),
// DR=100 (128 SPS → conversion 7.8ms), comparateur désactivé
#define ADS_CFG_BASE    0x8B83
#define ADS_MUX_C1      0x0000   // différentiel A0(+)/A1(−) → Cellule 1
#define ADS_MUX_C2      0x3000   // différentiel A2(+)/A3(−) → Cellule 2
// fabs() sur chaque lecture (héritée de GfredCCR v7.1) : absorbe un câblage
// cellule inversé (mapping A+/A− vs pins JST) — un signal réellement négatif
// est physiquement impossible sur une cellule galvanique
#define SENSOR_EMA_ALPHA 0.25f   // lissage exponentiel des mV (1.0 = aucun)

// Plage mV "live" plausible en fonctionnement (E4/CA) — différente du check
// air E3 (8-13mV) qui ne vaut qu'à 21% O2. En plongée les mV montent bien
// au-delà (jusqu'à ~80mV à PPO2 1.6). En-dessous du plancher = cellule
// débranchée/morte, au-dessus du plafond = court-circuit/anomalie.
#define CELL_MV_LIVE_MIN   2.0f
#define CELL_MV_LIVE_MAX  95.0f

// ── Batterie GPIO1 — vraie lecture (v4.0.0) ───────────────────────────
#define BAT_DIVIDER   2.0f      // pont 100kΩ/100kΩ → Vbat = Vadc × 2
#define BAT_TRIM      1.030f    // étalonné au multimètre : 3.682V réel / 3.575V affiché
#define BAT_PERIOD_MS 500       // période de rafraîchissement batterie
#define BAT_V_MAX  4.10f   // 100% — SOUS CHARGE SYSTÈME (mesure Fred : 4.1V affiché = pleine charge)
#define BAT_V_MIN  3.20f   //   0% (courbe LiPo — voir batteryPercent)
// Verrou radio batterie faible (v4.2) : plus jamais d'OTA sur batterie à
// genoux (brownout pendant l'écriture flash → décharge profonde, vécu !)
// v4.2.1 : seuils remontés — cohérents avec "sous 3.6V c'est mort"
#define BAT_V_RADIO_MIN 3.70f   // boot : en-dessous, WiFi/OTA/BLE désactivés (~30%)
#define BAT_V_RADIO_CUT 3.60f   // en session : radios coupées sous ce seuil (~15%)

// Seuil de divergence C1/C2 (TODO : algorithme voting v3.x)
#define PPO2_DIVERGE_THRESHOLD  0.15f

// ── Calibration CA1/CA2 ───────────────────────────────────────────────
// Plage mV valide — MANUEL rEvodream P/P5 officiel : 36-64 mV À L'O2 PUR.
// La plage est mise à l'échelle du FiO2 de référence courant :
//   plage_valide = [36..64] × (g_fio2_ref / 0.98)
// → à 0.98 (O2 pur) : 36.0–64.0 mV   → à 0.21 (air) : 7.7–13.7 mV
// Permet la calibration AIR complète au banc (cahier des charges §6).
#define CAL_MV_MIN_O2    36.0f
#define CAL_MV_MAX_O2    64.0f
#define FIO2_O2_PUR      0.98f
// FiO2 de référence PAR DÉFAUT tant que l'app BLE ne l'a pas écrit en NVS.
// BANC (travail à l'air) : 0.21f — PRODUCTION (O2 pur) : 0.98f
#define FIO2_DEFAULT     0.98f
// Valeur retenue = moyenne des vraies lectures sur les CA_AVG_MS dernières ms
// de la stabilisation (plus robuste qu'une lecture unique)
#define CA_AVG_MS        3000
#define CA1_DURATION_MS  10000  // durée de stabilisation avant résultat CA2
#define CA2_HOLD_MS       2000  // durée d'affichage du résultat avant retour E4 (v4.3.0)
// v5.8.0 — un ÉCHEC de calibration doit rester lisible : 2s suffisaient pour
// un "Calibration terminee" attendu, pas pour lire/comprendre/photographier
// une erreur (cas vécu Fred : calibration à l'air alors que FiO2 est à 0.98
// → les 8-13mV sont très loin de la fenêtre 36-64 → échec en 2s, illisible).
#define CA2_HOLD_ERR_MS  10000  // idem mais si au moins une cellule a échoué

// ── Icône montagne (config B) — taille partagée par E3, E4 et CA2 ─────
// v5.9.2 — agrandie (retour écran réel Fred) : 34x20 était lisible mais trop
// discret pour une info d'exception. UN SEUL point de réglage pour les 3
// écrans. ⚠️ Ces defines DOIVENT rester ici, très haut : E3 (showSplash3)
// les utilise vers la ligne 1150, bien avant drawE4Frame. Une macro utilisée
// avant sa définition ne compile pas — contrairement à une fonction, que
// l'IDE Arduino prototype automatiquement.
#define MTN_W      42   // largeur montagne (était 34)
#define MTN_H      24   // hauteur montagne (était 20)

// Déclaration anticipée : ces fonctions sont DÉFINIES près de drawE4Frame
// (drawMountain a besoin de dimColor(), déclarée plus bas), mais UTILISÉES
// dès E3. On ne s'en remet pas à l'auto-prototypage de l'IDE Arduino,
// historiquement capricieux avec les fonctions 'static'.
static void drawMountain(int cx, int ytop, int w, int h, uint16_t body, uint16_t snow);
static void drawSeaLevel(int cx, int ytop, int w, int h, uint16_t col);
// v5.10.0 — point d'entrée UNIQUE des 4 écrans (E3, CA1, CA2, E4).
// valueYTop < 0 → icône seule, sans la valeur chiffrée.
static void drawPressureRef(int cx, int ytop, int xl, int xr, int valueYTop);
// Anti-déclenchement accidentel : l'aimant doit être maintenu sur le reed NO
// pendant cette durée EN CONTINU pour lancer la calibration (choc, aimant
// qui passe, sac de plongée...). Le hardware est câblé — l'auto-test de banc
// (ex CA_AUTOTEST_MS) est supprimé depuis v4.1.2.
#define CAL_REED_HOLD_MS  1000

// ═══════════════════════════════════════════════════════════════════════
//  ÉTAT GLOBAL — partagé entre E3 et E4
// ═══════════════════════════════════════════════════════════════════════

// Structure d'état d'une cellule O2
struct CellState {
    float mv;    // millivolts bruts lus par ADS1115
    float ppo2;  // PPO2 calculée en bar (mv / mv_calib × FiO2)
    bool  ok;    // true si mv dans plage valide à l'air
};

// Rempli par showSplash3() (E3), utilisé par drawE4Frame() (E4)
CellState g_c1    = {0, 0, false};
CellState g_c2    = {0, 0, false};
float     g_bat_v   = 0.0f;
int       g_bat_pct = 0;

// Calibration — persistée en NVS (namespace "gfred") depuis v4.0.0
float g_calib_c1 = 0.0f;   // mV mesuré à O2 pur lors de la dernière calib
float g_calib_c2 = 0.0f;
float g_fio2_ref = 0.98f;   // FiO2 référence calibration (O2 pur = 1.0)
// v5.7.0 — pression de calibration en mbar. 1013 = config A = défaut =
// comportement strictement identique aux versions <= 5.6.0 (le facteur
// mbar/1013 vaut alors exactement 1.0). Constantes dans gfred_params.h.
uint16_t g_mbar_ref = MBAR_DEFAULT;

// Latch de confiance : une cellule qui rate le check air E3 reste KO en E4
// jusqu'à une calibration CA réussie qui la réhabilite (sécurité plongée)
// v5.9.0 — dernière TENTATIVE de calibration échouée, PAR CELLULE et
// PERSISTÉE en NVS (demande Fred 24/07 : "et cela même après reboot !!!!").
// Persister est le bon choix : une tentative ratée laisse l'appareil sur une
// calibration ANCIENNE, et ce fait ne disparaît pas parce qu'on a coupé le
// courant. Couper/rallumer ne doit jamais effacer un avertissement.
// Par cellule (et non global) pour permettre le mode dégradé : une cellule
// débranchée ou morte doit être DÉSIGNÉE, l'autre continuant de servir.
bool g_c1_cal_ko = false;
bool g_c2_cal_ko = false;

// v5.11.0 — RÉFÉRENCES DE LA CALIBRATION EN COURS (relues au boot, mises à
// jour à chaque calibration). Auparavant locales à calibLoad(), elles sont
// désormais globales pour permettre le contrôle EN CONTINU : une calibration
// n'est valable QUE pour le couple (FiO2, pression) auquel elle a été faite.
// Comparer en permanence g_fio2_ref/g_mbar_ref à ces deux valeurs permet de
// détecter une incohérence immédiatement, sans attendre un redémarrage.
float    g_cal_fio2 = 0.98f;
uint16_t g_cal_mbar = MBAR_DEFAULT;

// Calibration exploitable ? Idée Fred (24/07) : plutôt que d'afficher une
// PPO2 fausse — ou pire, "0.00", chiffre plausible qui tombe dans la zone
// hypoxie et fait hurler le HUD alors que la vraie information est "je ne
// sais pas" — on affiche des TIRETS. Des tirets ne mentent pas et forcent
// la recalibration.
static inline bool calRefMatch() {
    return (g_mbar_ref == g_cal_mbar) && (fabsf(g_fio2_ref - g_cal_fio2) <= 0.005f);
}
static inline bool c1CalOk() { return g_calib_c1 > 1.0f && calRefMatch(); }
static inline bool c2CalOk() { return g_calib_c2 > 1.0f && calRefMatch(); }

// Formate une PPO2 : valeur si exploitable, "---" sinon.
static void fmtPPO2(char *out, size_t n, float ppo2, bool ok) {
    if (ok) snprintf(out, n, "%.2f", ppo2);
    else    snprintf(out, n, "---");
}

// v5.8.1 — dernière TENTATIVE de calibration échouée (drapeau de session).
// Indispensable et distinct de "g_calib_cX == 0" : depuis la v4.x, un échec
// de calibration ne détruit PAS la calibration précédente valide (règle de
// sécurité voulue). Donc après un échec, g_calib_c1/c2 restent > 0 et aucun
// test sur leur valeur ne peut détecter l'échec — bug remonté par Fred le
// 24/07 (calibration lancée à l'air avec FiO2 0.98 → échec → rien sur E4).
// Volontairement NON persisté en NVS : au reboot, la calibration réellement
// utilisée est l'ancienne, qui était valide. Le pense-bête d'E3 couvre déjà
// le risque d'une calibration simplement trop ancienne.


// ADS1115 détecté au boot — si absent, cellules KO → AL_DEAD (OTA reste actif)
bool g_ads_ok = false;

Preferences prefs;   // NVS — calibration persistée

// Mode HUD : 0=CCR 4P (défaut), 1=Smithers 5P, 2=SCR 6P
// TODO : configurable via BLE (chat 3.1 BT)
uint8_t g_hud_mode = 0;

// ═══════════════════════════════════════════════════════════════════════
//  CAPTEURS — ADS1115 (Wire brut, sans bibliothèque externe) + BATTERIE
//  v4.0.0 : remplace toutes les valeurs simulées CELL*_SIM / CAL*_SIM
// ═══════════════════════════════════════════════════════════════════════

// Détection de présence sur le bus I2C (ACK à l'adresse 0x48)
bool adsPresent() {
    Wire.beginTransmission(ADS_ADDR);
    return Wire.endTransmission() == 0;
}

// Lance une conversion single-shot sur le mux différentiel demandé
void adsStart(uint16_t mux) {
    uint16_t cfg = ADS_CFG_BASE | mux;
    Wire.beginTransmission(ADS_ADDR);
    Wire.write(ADS_REG_CONFIG);
    Wire.write((uint8_t)(cfg >> 8));
    Wire.write((uint8_t)(cfg & 0xFF));
    Wire.endTransmission();
}

// true si la conversion en cours est terminée (bit OS=1 du registre config)
bool adsReady() {
    Wire.beginTransmission(ADS_ADDR);
    Wire.write(ADS_REG_CONFIG);
    if (Wire.endTransmission() != 0) return false;
    if (Wire.requestFrom((uint8_t)ADS_ADDR, (uint8_t)2) != 2) return false;
    uint16_t cfg = ((uint16_t)Wire.read() << 8) | Wire.read();
    return (cfg & 0x8000) != 0;
}

// Lit le résultat de conversion en mV (signé) — NAN si erreur I2C
float adsReadMv() {
    Wire.beginTransmission(ADS_ADDR);
    Wire.write(ADS_REG_CONV);
    if (Wire.endTransmission() != 0) return NAN;
    if (Wire.requestFrom((uint8_t)ADS_ADDR, (uint8_t)2) != 2) return NAN;
    int16_t raw = ((int16_t)Wire.read() << 8) | (int16_t)Wire.read();
    return (float)raw * ADS_LSB_MV;
}

// Lecture BLOQUANTE d'une cellule (~10ms) — utilisée au boot avant E3
// cell : 0 = Cellule 1 (A0/A1), 1 = Cellule 2 (A2/A3)
float adsReadCellMvBlocking(uint8_t cell) {
    if (!g_ads_ok) return 0.0f;
    adsStart(cell == 0 ? ADS_MUX_C1 : ADS_MUX_C2);
    uint32_t t0 = millis();
    while (!adsReady()) {
        if (millis() - t0 > 25) return 0.0f;   // timeout sécurité
        delay(1);
    }
    float mv = adsReadMv();
    if (isnan(mv)) return 0.0f;
    return fabsf(mv);   // absorbe un câblage cellule inversé (cf. GfredCCR)
}

// Tension batterie via GPIO1 (ADC calibré usine) × pont diviseur.
// NB : le pont 100k/100k présente ~50kΩ d'impédance de source à l'ADC —
// bien au-dessus des ~10kΩ recommandés. Sans condensateur sur GPIO1, la
// 1re lecture après commutation est basse : on la jette, puis on moyenne
// 8 échantillons espacés de 300µs pour laisser le sample-cap se charger.
// Étalonnage final : mesurer Vbat au multimètre et ajuster BAT_TRIM
// (BAT_TRIM = V_multimètre / V_affiché, à tolérances des résistances près).
float readBatteryVolts() {
    (void)analogReadMilliVolts(PIN_BAT_ADC);   // lecture de purge, jetée
    uint32_t acc = 0;
    for (int i = 0; i < 8; i++) {
        delayMicroseconds(300);
        acc += analogReadMilliVolts(PIN_BAT_ADC);
    }
    return ((float)(acc / 8) / 1000.0f) * BAT_DIVIDER * BAT_TRIM;
}

// Courbe de décharge LiPo 1S recalée SOUS CHARGE SYSTÈME (v4.2.1) :
// mesure Fred : 4.1V affiché = batterie pleine → la tension lue sous charge
// (AMOLED + ESP32) est ~0.1V sous la tension à vide. Toute la courbe est
// décalée en conséquence. 3.6V affiché = ~15% = zone morte, radios coupées.
int batteryPercent(float v) {
    static const float tv[] = {4.10f,4.00f,3.90f,3.80f,3.70f,3.60f,3.50f,3.40f,3.30f,3.20f};
    static const int   tp[] = {  100,   88,   70,   50,   30,   15,    8,    4,    1,    0};
    if (v >= tv[0]) return 100;
    for (int i = 1; i < 10; i++)
        if (v >= tv[i])
            return tp[i] + (int)((tp[i-1]-tp[i]) * (v-tv[i]) / (tv[i-1]-tv[i]));
    return 0;
}

// Radios (WiFi/OTA, BLE futur) autorisées ? Décidé au boot selon la
// tension batterie, coupé en session si elle passe sous BAT_V_RADIO_CUT.
bool g_radios_on = false;
// BLE réellement opérationnel — vrai uniquement quand un client est
// connecté (CbServer::onConnect, ble_service.h) → l'indicateur BTH d'E4 verdit
bool g_ble_up    = false;

// ── Lot 4 — bouton CALIBRER distant (double confirmation ARM/GO) ───────
bool     g_ble_calib_armed   = false;
uint32_t g_ble_calib_arm_ms  = 0;
bool     g_ble_calib_trigger = false;

// v5.7.0 — facteur de correction pression. Vaut EXACTEMENT 1.0 en config A
// (g_mbar_ref = 1013), donc toutes les formules ci-dessous sont inchangées
// tant que Fred ne touche à rien. Un seul point de vérité pour les 4
// endroits qui en ont besoin (cellCompute, aperçu CA1, plage calib CA1).
static inline float mbarFactor() { return (float)g_mbar_ref / MBAR_STD; }

// Calcule ppo2 + validité live d'une cellule à partir de ses mV lissés
// PPO2 = mv / calib_mv × FiO2_ref × (mbar/1013)
// La pression est celle DE LA CALIBRATION, pas la pression courante : une
// fois calibrée, la cellule mesure une PPO2 absolue et n'a plus besoin de
// savoir où elle est. Le verrou de calibLoad() garantit g_mbar_ref ==
// calmbar (sinon la calib est invalidée), donc utiliser g_mbar_ref ici est
// correct — même raisonnement que pour g_fio2_ref depuis la v4.0.0.
// v5.13.0 — GRAND NETTOYAGE. cellCompute ne dépend plus d'un "latch de
// confiance" hérité du verdict E3. c.ok signifie désormais UNE SEULE chose,
// vérifiable et physique : "la cellule produit-elle un signal exploitable ?"
// (plage vitale 2-95mV). Fini l'inférence "cette cellule est-elle saine ?",
// que l'appareil ne peut pas faire sans connaître le gaz de la boucle.
// Philosophie (décision Fred 24/07) : l'appareil MESURE et AFFICHE, il ne
// juge pas. Comme le Shearwater, qui n'a aucune barrière au démarrage.
// La santé fine des cellules se lit ailleurs : divergence C1/C2 en direct,
// et contrôle 1.60 bar de la PWA (seul vrai test de current-limiting — une
// cellule en fin de vie PLAFONNE et lit BAS, jamais haut : aucun seuil mV
// haut ne la détecterait, cf. recherche du 24/07).
void cellCompute(CellState &c, float calib_mv) {
    c.ok   = (c.mv >= CELL_MV_LIVE_MIN && c.mv <= CELL_MV_LIVE_MAX);
    c.ppo2 = (calib_mv > 1.0f) ? (c.mv / calib_mv) * g_fio2_ref * mbarFactor() : 0.0f;
    if (c.ppo2 < 0.0f) c.ppo2 = 0.0f;
}

// ── Machine d'état NON-BLOQUANTE — appelée à chaque frame (E4 et CA1) ──
// Une conversion ADS1115 dure 7.8ms @128SPS : on la lance, on rend la main,
// on relève le résultat à la frame suivante en alternant C1/C2 (~12Hz/cellule,
// largement suffisant pour des cellules O2 qui répondent en secondes).
void sensorsUpdate() {
    static uint8_t  chan       = 0;      // 0 = C1, 1 = C2
    static bool     converting = false;
    static uint32_t t_conv     = 0;
    static uint32_t t_bat      = 0;

    // ── Cellules O2 ──────────────────────────────────────────────────
    if (!g_ads_ok) {
        g_c1.ok = false;
        g_c2.ok = false;
    } else if (!converting) {
        adsStart(chan == 0 ? ADS_MUX_C1 : ADS_MUX_C2);
        converting = true;
        t_conv = millis();
    } else if (adsReady() || millis() - t_conv > 25) {
        float mv = adsReadMv();
        if (!isnan(mv)) {
            mv = fabsf(mv);   // absorbe un câblage cellule inversé (cf. GfredCCR)
            CellState &c = (chan == 0) ? g_c1 : g_c2;
            c.mv += SENSOR_EMA_ALPHA * (mv - c.mv);   // lissage EMA
            cellCompute(c, (chan == 0) ? g_calib_c1 : g_calib_c2);
        }
        chan ^= 1;            // alterne C1 → C2 → C1 ...
        converting = false;
    }

    // ── Batterie — toutes les BAT_PERIOD_MS ─────────────────────────
    if (millis() - t_bat >= BAT_PERIOD_MS) {
        t_bat = millis();
        float v = readBatteryVolts();
        g_bat_v  += 0.3f * (v - g_bat_v);   // léger lissage
        g_bat_pct = batteryPercent(g_bat_v);   // courbe LiPo réelle (v4.2)

        // Coupure radio en session : sous BAT_V_RADIO_CUT, on sacrifie
        // l'OTA et le BLE pour préserver l'instrument (et la batterie)
        if (g_radios_on && g_bat_v < BAT_V_RADIO_CUT) {
            g_radios_on = false;
            WiFi.disconnect(true);
            WiFi.mode(WIFI_OFF);
            bleStop();
            Serial.printf("Batterie %.2fV < %.2fV -> radios coupees\n",
                          g_bat_v, BAT_V_RADIO_CUT);
        }
    }
}

// ── Persistance NVS de la calibration (namespace "gfred") ─────────────
// Règle de sécurité : une calibration n'est valide QUE pour le FiO2 auquel
// elle a été réalisée (ppo2 = mv/calib × fio2). Si le FiO2 de référence a
// changé depuis (define FIO2_DEFAULT modifié, ou écrit via BLE plus tard)
// → calibration invalidée au boot → fallback air + "DON'T FORGET CALIBRATE !"
// NB : la clé NVS "fio2" est réservée à l'app BLE (source prioritaire) ;
// tant qu'elle n'existe pas, c'est le define FIO2_DEFAULT qui fait foi.
void calibLoad() {
    prefs.begin("gfred", false);
    g_calib_c1     = prefs.getFloat("cal1", 0.0f);
    g_calib_c2     = prefs.getFloat("cal2", 0.0f);
    g_fio2_ref     = prefs.getFloat("fio2", FIO2_DEFAULT);
    g_cal_fio2     = prefs.getFloat("calfio2", g_fio2_ref);
    // v5.7.0 — même schéma pour la pression. Défaut MBAR_DEFAULT (1013) tant
    // que la PWA n'a jamais écrit : un appareil qui monte de v5.6.0 en OTA
    // trouve donc 1013 et se comporte exactement comme avant. La clé
    // "calmbar" par défaut = g_mbar_ref → une calibration faite sous v5.6.0
    // (donc à 1013 implicite) n'est PAS invalidée au premier boot v5.7.0.
    g_mbar_ref      = prefs.getUShort("mbar",    MBAR_DEFAULT);
    g_cal_mbar      = prefs.getUShort("calmbar", g_mbar_ref);
    g_c1_cal_ko     = prefs.getBool("c1ko", false);   // v5.9.0 — survit au reboot
    g_c2_cal_ko     = prefs.getBool("c2ko", false);
    prefs.end();

    // Garde-fou : une valeur NVS corrompue/hors plage ne doit jamais fausser
    // silencieusement toutes les PPO2. On retombe sur la config A.
    if (g_mbar_ref < MBAR_MIN || g_mbar_ref > MBAR_MAX) {
        Serial.printf("Pression NVS hors plage (%u) -> retour 1013 (config A)\n", g_mbar_ref);
        g_mbar_ref = MBAR_DEFAULT;
    }

    // v5.11.0 — on n'EFFACE PLUS cal1/cal2. La calibration reste en mémoire ;
    // c'est calRefMatch() qui décide en continu si elle est exploitable. Deux
    // gains : (1) l'incohérence est détectée immédiatement, pas seulement au
    // boot — plus de fenêtre où l'écran afficherait une valeur fausse sans
    // rien signaler ; (2) une écriture BLE erronée devient RÉVERSIBLE — il
    // suffit de réécrire la valeur d'origine pour retrouver sa calibration,
    // au lieu de devoir refaire un lavage O2 complet pour une faute de frappe.
    if (g_calib_c1 > 0.0f || g_calib_c2 > 0.0f) {
        if (fabsf(g_fio2_ref - g_cal_fio2) > 0.005f)
            Serial.printf("FiO2 (%.2f) != FiO2 de calib (%.2f) -> PPO2 masquee, recalibrer !\n",
                          g_fio2_ref, g_cal_fio2);
        if (g_mbar_ref != g_cal_mbar)
            Serial.printf("Pression (%u) != pression de calib (%u mbar) -> PPO2 masquee, recalibrer !\n",
                          g_mbar_ref, g_cal_mbar);
    }

    Serial.printf("Config %c : %u mbar (facteur %.4f)\n",
                  (g_mbar_ref == MBAR_DEFAULT) ? 'A' : 'B',
                  g_mbar_ref, (float)g_mbar_ref / MBAR_STD);
}

void calibSave() {
    prefs.begin("gfred", false);
    prefs.putFloat("cal1", g_calib_c1);
    prefs.putFloat("cal2", g_calib_c2);
    g_cal_fio2 = g_fio2_ref;                 // v5.11.0 — références de CETTE calib
    g_cal_mbar = g_mbar_ref;
    prefs.putFloat("calfio2", g_fio2_ref);   // FiO2 auquel cette calib a été faite
    prefs.putUShort("calmbar", g_mbar_ref);  // pression à laquelle cette calib a été faite (v5.7.0)
    prefs.putBool("c1ko", g_c1_cal_ko);      // v5.9.0 — échec par cellule, persisté
    prefs.putBool("c2ko", g_c2_cal_ko);
    prefs.end();
}

// ═══════════════════════════════════════════════════════════════════════
//  OBJETS DISPLAY ET BUFFERS PSRAM
// ═══════════════════════════════════════════════════════════════════════

Arduino_DataBus *bus     = new Arduino_ESP32QSPI(LCD_CS,LCD_SCLK,LCD_D0,LCD_D1,LCD_D2,LCD_D3);
Arduino_CO5300  *display = new Arduino_CO5300(bus,LCD_RST,0,PHYS_W,PHYS_H,20,0);

// 4 buffers alloués en PSRAM (~1MB total sur 8MB dispo)
uint16_t *framebuf     = nullptr;  // dessin courant 456×280
uint16_t *portrait_buf = nullptr;  // rotation 280×456 pour envoi écran
uint16_t *textbuf      = nullptr;  // pré-rendu / source fondu entrant
uint16_t *crossbuf     = nullptr;  // source fondu sortant

// Canvas pour rendu polices Adafruit GFX dans framebuf PSRAM
Arduino_Canvas *canvas      = nullptr;  // 456×60px  — polices normales
Arduino_Canvas *canvasLarge = nullptr;  // 456×120px — PPO2 géant ×2

// ═══════════════════════════════════════════════════════════════════════
//  PRIMITIVES FRAMEBUFFER
// ═══════════════════════════════════════════════════════════════════════

// Mélange alpha RGB565 — utilisé pour fondus, transparences et sprites
static inline uint16_t blend565(uint16_t bg, uint16_t fg, uint8_t a) {
    if (a == 0)   return bg;
    if (a == 255) return fg;
    uint8_t r = ((((fg>>11)&31)*a) + (((bg>>11)&31)*(255-a))) >> 8;
    uint8_t g = ((((fg>>5) &63)*a) + (((bg>>5) &63)*(255-a))) >> 8;
    uint8_t b = (((fg&31)      *a) + ((bg&31)       *(255-a))) >> 8;
    return (r<<11) | (g<<5) | b;
}

// Remplissage total du framebuffer
void fbFill(uint16_t c) {
    uint32_t n = (uint32_t)LAND_W * LAND_H;
    for (uint32_t i = 0; i < n; i++) framebuf[i] = c;
}

// Rectangle plein
void fbRect(int x, int y, int w, int h, uint16_t c) {
    for (int row = max(0,y); row < min(LAND_H,y+h); row++)
        for (int col = max(0,x); col < min(LAND_W,x+w); col++)
            framebuf[row*LAND_W+col] = c;
}

// Rectangle avec alpha (semi-transparent sur le fond existant)
void fbRectAlpha(int x, int y, int w, int h, uint16_t c, uint8_t a) {
    for (int row = max(0,y); row < min(LAND_H,y+h); row++)
        for (int col = max(0,x); col < min(LAND_W,x+w); col++) {
            int i = row*LAND_W+col;
            framebuf[i] = blend565(framebuf[i], c, a);
        }
}

// Copie d'une image PROGMEM dans le framebuffer
void fbCopyBg()   { const uint16_t *s=SPLASH_BG;   uint32_t n=(uint32_t)LAND_W*LAND_H; for(uint32_t i=0;i<n;i++) framebuf[i]=s[i]; }
void fbCopyFond() { const uint16_t *s=SPLASH_FOND;  uint32_t n=(uint32_t)LAND_W*LAND_H; for(uint32_t i=0;i<n;i++) framebuf[i]=s[i]; }

// Rotation 90° CCW + envoi vers l'écran physique portrait
void flushToDisplay() {
    for (int row = 0; row < PHYS_H; row++) {
        int lx      = PHYS_H - 1 - row;
        int dst_off = row * PHYS_W;
        for (int col = 0; col < PHYS_W; col++)
            portrait_buf[dst_off+col] = framebuf[col*LAND_W+lx];
    }
    display->draw16bitRGBBitmap(0, 0, portrait_buf, PHYS_W, PHYS_H);
}

// Sauvegarde du framebuffer dans un buffer intermédiaire
void saveToCrossbuf() { memcpy(crossbuf, framebuf, (size_t)LAND_W*LAND_H*2); }
void saveToTextbuf()  { memcpy(textbuf,  framebuf, (size_t)LAND_W*LAND_H*2); }

// ═══════════════════════════════════════════════════════════════════════
//  FONDU ENCHAÎNÉ — transition fluide entre deux images
//  src → dst en `frames` étapes de `ms` millisecondes chacune
// ═══════════════════════════════════════════════════════════════════════
// (crossFade supprimée v4.3.0 — code mort : fondus E1-E3 en boucles inline)

// ═══════════════════════════════════════════════════════════════════════
//  SPRITES — images PNG avec canal alpha et teinte couleur
//  Utilisés pour sprite_ok (E3) et sprite_ko (E3 + E4 cellule KO)
//  cx/cy = centre du sprite, tint = couleur de teinte (0 = pas de teinte)
// ═══════════════════════════════════════════════════════════════════════
void fbDrawSpriteTinted(int cx, int cy,
                        const uint16_t *rgb, const uint8_t *alpha,
                        int w, int h, uint16_t tint) {
    int sx = cx-w/2, sy = cy-h/2;
    for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
        uint8_t a = pgm_read_byte(&alpha[y*w+x]);
        if (a < 8) continue;
        int px = sx+x, py = sy+y;
        if (px < 0 || px >= LAND_W || py < 0 || py >= LAND_H) continue;
        uint16_t col = pgm_read_word(&rgb[y*w+x]);
        if (tint != 0) {
            uint8_t lum = (uint8_t)((((col>>11)&31)*8+((col>>5)&63)*4+(col&31)*8)/3);
            col = (lum > 160) ? COL_WHITE : blend565(col, tint, 200);
        }
        uint16_t bg = blend565(COL_BLACK, framebuf[py*LAND_W+px], 40);
        framebuf[py*LAND_W+px] = blend565(bg, col, a);
    }
}

// v5.5.0 — mini-crâne divergence voting : RÉUTILISE le sprite AL_DEAD tel
// quel (SPRITE_DEAD/SPRITE_DEAD_ALPHA, 220×220), aucun octet de plus en
// flash. `step` sous-échantillonne (step=4 → sortie ~55×55, tient dans la
// colonne voting 83px de large). Un seul pixel source sur `step` est lu,
// donc plus léger en calcul que la version pleine taille, pas juste en
// mémoire.
void fbDrawSpriteTintedScaled(int cx, int cy,
                              const uint16_t *rgb, const uint8_t *alpha,
                              int w, int h, uint16_t tint, int step) {
    int ow = w/step, oh = h/step;
    int sx = cx-ow/2, sy = cy-oh/2;
    for (int oy = 0; oy < oh; oy++) for (int ox = 0; ox < ow; ox++) {
        int x = ox*step, y = oy*step;
        uint8_t a = pgm_read_byte(&alpha[y*w+x]);
        if (a < 8) continue;
        int px = sx+ox, py = sy+oy;
        if (px < 0 || px >= LAND_W || py < 0 || py >= LAND_H) continue;
        uint16_t col = pgm_read_word(&rgb[y*w+x]);
        if (tint != 0) {
            uint8_t lum = (uint8_t)((((col>>11)&31)*8+((col>>5)&63)*4+(col&31)*8)/3);
            col = (lum > 160) ? COL_WHITE : blend565(col, tint, 200);
        }
        uint16_t bg = blend565(COL_BLACK, framebuf[py*LAND_W+px], 40);
        framebuf[py*LAND_W+px] = blend565(bg, col, a);
    }
}

// ═══════════════════════════════════════════════════════════════════════
//  RENDU TEXTE via canvas PSRAM
//
//  Deux systèmes de coordonnées y selon le contexte :
//
//  fbDrawTextFreeSans() — y = BASELINE (bas des lettres sans descendantes)
//    Utilisé pour les textes dont on connaît la position exacte
//    ex: Cell 1 baseline=18, mV baseline=175, PPO2 baseline=180
//
//  fbDrawTextTop() — y = HAUT VISIBLE du texte
//    Détecte automatiquement la 1ère ligne non-vide du canvas
//    Utilisé pour les éléments collés en haut (Voting, CCR, volts)
//    ex: "Voting" y_top=10, chiffre voting y_top=40, volts y_top=260
//
//  fbTextHugeLeft/Right() — via canvasLarge 456×120px avec setTextSize(2)
//    FreeSansBold24pt × 2 ≈ 48pt réel, ~82px de hauteur visible
//    y = baseline (même système que fbDrawTextFreeSans)
// ═══════════════════════════════════════════════════════════════════════

// Rendu de base — y = baseline
void fbDrawTextFreeSans(int x, int y, const char *txt, uint16_t color, const GFXfont *font) {
    if (!canvas) return;
    int ch = canvas->height(), cw = canvas->width();
    canvas->fillScreen(COL_BLACK);
    canvas->setFont(font); canvas->setTextColor(COL_WHITE); canvas->setTextSize(1);
    canvas->setCursor(0, ch-6);
    canvas->print(txt);
    uint16_t *cbuf = canvas->getFramebuffer();
    for (int cy = 0; cy < ch; cy++) {
        int fy = y+cy; if (fy < 0 || fy >= LAND_H) continue;
        for (int cx2 = 0; cx2 < cw; cx2++) {
            int fx = x+cx2; if (fx < 0 || fx >= LAND_W) continue;
            uint16_t px = cbuf[cy*cw+cx2]; if (px == COL_BLACK) continue;
            uint8_t a = (((px>>11)&31)*255)/31;
            if (a > 10) framebuf[fy*LAND_W+fx] = blend565(framebuf[fy*LAND_W+fx], color, a);
        }
    }
}

// Mesure la largeur d'un texte pour centrage et alignement droite
int textWidthFS(const char *txt, const GFXfont *font) {
    if (!canvas) return strlen(txt)*10;
    canvas->setFont(font); canvas->setTextSize(1);
    int16_t x1,y1; uint16_t w,h;
    canvas->getTextBounds(txt, 0, 40, &x1, &y1, &w, &h);
    return w;
}

// Centré sur tout l'écran — y = baseline
void fbDrawTextCenteredFS(int y, const char *txt, uint16_t color, const GFXfont *font) {
    fbDrawTextFreeSans((LAND_W - textWidthFS(txt,font)) / 2, y, txt, color, font);
}

// Centré dans une colonne [xl,xr] — y = baseline
void fbDrawTextColCenteredFS(int xl, int xr, int y, const char *txt, uint16_t color, const GFXfont *font) {
    fbDrawTextFreeSans(xl + (xr-xl-textWidthFS(txt,font)) / 2, y, txt, color, font);
}

// Aligné gauche — y = baseline
void fbDrawTextLeftFS(int xl, int y, const char *txt, uint16_t color, const GFXfont *font) {
    fbDrawTextFreeSans(xl, y, txt, color, font);
}

// Aligné droite — y = baseline
void fbDrawTextRightFS(int xr, int y, const char *txt, uint16_t color, const GFXfont *font) {
    fbDrawTextFreeSans(xr - textWidthFS(txt, font) - 4, y, txt, color, font);
}

// ── Variantes "Top" : y = haut visible du texte ───────────────────────

// Rendu avec y = haut visible (détecte automatiquement first_row)
void fbDrawTextTop(int x, int y_top, const char *txt, uint16_t color, const GFXfont *font) {
    if (!canvas) return;
    int ch = canvas->height(), cw = canvas->width();
    canvas->fillScreen(COL_BLACK);
    canvas->setFont(font); canvas->setTextColor(COL_WHITE); canvas->setTextSize(1);
    canvas->setCursor(0, ch-6);
    canvas->print(txt);
    uint16_t *cbuf = canvas->getFramebuffer();
    // Trouver la première ligne non-vide = haut réel du texte dans le canvas
    int first_row = 0;
    for (int cy = 0; cy < ch; cy++) {
        bool found = false;
        for (int cx2 = 0; cx2 < cw; cx2++) if (cbuf[cy*cw+cx2] != COL_BLACK) { found=true; break; }
        if (found) { first_row = cy; break; }
    }
    int offset = y_top - first_row;
    for (int cy = 0; cy < ch; cy++) {
        int fy = cy + offset; if (fy < 0 || fy >= LAND_H) continue;
        for (int cx2 = 0; cx2 < cw; cx2++) {
            int fx = x+cx2; if (fx < 0 || fx >= LAND_W) continue;
            uint16_t px = cbuf[cy*cw+cx2]; if (px == COL_BLACK) continue;
            uint8_t a = (((px>>11)&31)*255)/31;
            if (a > 10) framebuf[fy*LAND_W+fx] = blend565(framebuf[fy*LAND_W+fx], color, a);
        }
    }
}

// Centré dans une colonne — y = haut visible
void fbTextCenterTop(int xl, int xr, int y_top, const char *txt, uint16_t color, const GFXfont *font) {
    canvas->setFont(font); canvas->setTextSize(1);
    int16_t x1,y1; uint16_t w,h;
    canvas->getTextBounds(txt, 0, 40, &x1, &y1, &w, &h);
    fbDrawTextTop(xl + (xr-xl-(int)w)/2, y_top, txt, color, font);
}

// Centré — y = baseline (alias court pour les splashs)
void fbTextLeft  (int xl,      int y, const char *t, uint16_t c, const GFXfont *f) { fbDrawTextFreeSans(xl,y,t,c,f); }
void fbTextRight (int xr,      int y, const char *t, uint16_t c, const GFXfont *f) { fbDrawTextFreeSans(xr-textWidthFS(t,f)-4,y,t,c,f); }
void fbTextCenter(int xl, int xr, int y, const char *t, uint16_t c, const GFXfont *f) { fbDrawTextFreeSans(xl+(xr-xl-textWidthFS(t,f))/2,y,t,c,f); }

// ── Texte géant ×2 pour PPO2 C1/C2 ──────────────────────────────────

// FreeSansBold24pt + setTextSize(2) ≈ 48pt réel, ~82px de haut
// Aligné gauche — y = baseline
void fbTextHugeLeft(int xl, int y, const char *txt, uint16_t color, const GFXfont *font) {
    if (!canvasLarge) { fbTextLeft(xl, y, txt, color, font); return; }
    int ch = canvasLarge->height(), cw = canvasLarge->width();
    canvasLarge->fillScreen(COL_BLACK);
    canvasLarge->setFont(font); canvasLarge->setTextColor(COL_WHITE); canvasLarge->setTextSize(2);
    canvasLarge->setCursor(0, ch-10); canvasLarge->print(txt);
    uint16_t *cbuf = canvasLarge->getFramebuffer();
    for (int cy = 0; cy < ch; cy++) {
        int fy = y-ch+cy; if (fy < 0 || fy >= LAND_H) continue;
        for (int cx2 = 0; cx2 < cw; cx2++) {
            int fx = xl+cx2; if (fx < 0 || fx >= LAND_W) continue;
            uint16_t px = cbuf[cy*cw+cx2]; if (px == COL_BLACK) continue;
            uint8_t a = (((px>>11)&31)*255)/31;
            if (a > 10) framebuf[fy*LAND_W+fx] = blend565(framebuf[fy*LAND_W+fx], color, a);
        }
    }
}

// Aligné droite — y = baseline
void fbTextHugeRight(int xr, int y, const char *txt, uint16_t color, const GFXfont *font) {
    if (!canvasLarge) { fbTextRight(xr, y, txt, color, font); return; }
    int ch = canvasLarge->height(), cw = canvasLarge->width();
    canvasLarge->fillScreen(COL_BLACK);
    canvasLarge->setFont(font); canvasLarge->setTextColor(COL_WHITE); canvasLarge->setTextSize(2);
    canvasLarge->setCursor(0, ch-10); canvasLarge->print(txt);
    int16_t bx,by; uint16_t bw,bh;
    canvasLarge->getTextBounds(txt, 0, ch-10, &bx, &by, &bw, &bh);
    int ox = xr - (int)bw - 8;  // marge 8px du bord droit
    uint16_t *cbuf = canvasLarge->getFramebuffer();
    for (int cy = 0; cy < ch; cy++) {
        int fy = y-ch+cy; if (fy < 0 || fy >= LAND_H) continue;
        for (int cx2 = 0; cx2 < cw; cx2++) {
            int fx = ox+cx2; if (fx < 0 || fx >= LAND_W) continue;
            uint16_t px = cbuf[cy*cw+cx2]; if (px == COL_BLACK) continue;
            uint8_t a = (((px>>11)&31)*255)/31;
            if (a > 10) framebuf[fy*LAND_W+fx] = blend565(framebuf[fy*LAND_W+fx], color, a);
        }
    }
}

// ═══════════════════════════════════════════════════════════════════════
//  SPLASH 0 — Logo GfredDream animé sur fond plongeur CCR
//  !! NE PAS MODIFIER — validé et parfait !!
// ═══════════════════════════════════════════════════════════════════════

// Courbe d'accélération cubique avec rebond final (~85% du trajet)
float easeOut(float t) {
    float e = 1.0f - (1.0f-t)*(1.0f-t)*(1.0f-t);
    if (t > 0.85f) e += 0.04f * sinf((t-0.85f)/0.15f * 3.14159f);
    return e;
}

// Dessin du logo GfredDream avec zoom, alpha et perspective verticale
void drawLogo(float scale, uint8_t alphaG, float persp) {
    int fw = max(2,(int)(LOGO_W*scale)), fh = max(1,(int)(LOGO_H*scale*persp));
    int cx = LOGO_FINAL_X+LOGO_W/2, cy = LOGO_FINAL_Y+LOGO_H/2;
    int sx = cx-fw/2, sy = cy-fh/2;
    for (int fy = 0; fy < fh; fy++) {
        int sy2 = sy+fy; if (sy2 < 0 || sy2 >= LAND_H) continue;
        int ly = (fy*LOGO_H)/fh;
        for (int fx2 = 0; fx2 < fw; fx2++) {
            int sx2 = sx+fx2; if (sx2 < 0 || sx2 >= LAND_W) continue;
            int lx = (fx2*LOGO_W)/fw;
            uint8_t a = SPLASH_LOGO_ALPHA[ly*LOGO_W+lx]; if (a < 4) continue;
            uint16_t af = ((uint16_t)a*alphaG) >> 8; if (af > 255) af = 255;
            framebuf[sy2*LAND_W+sx2] = blend565(framebuf[sy2*LAND_W+sx2], COL_WHITE, (uint8_t)af);
        }
    }
}

void showSplashBoot() {
    fbCopyBg(); flushToDisplay(); delay(100);
    for (int i = 0; i < 30; i++) {   // zoom in 30 frames × 41ms
        float t = (float)i/29.0f, ease = easeOut(t);
        fbCopyBg();
        drawLogo(0.05f+ease*0.95f, (uint8_t)min(255.0f,t*2.8f*255.0f), 0.65f+ease*0.35f);
        flushToDisplay(); delay(41);
    }
    fbCopyBg(); drawLogo(1.0f, 255, 1.0f); flushToDisplay(); delay(2000);
    for (int i = 19; i >= 0; i--) {  // zoom out 20 frames × 20ms
        float t = (float)i/19.0f, ease = easeOut(t);
        fbCopyBg();
        drawLogo(0.05f+ease*0.95f, (uint8_t)min(255.0f,t*2.8f*255.0f), 0.65f+ease*0.35f);
        flushToDisplay(); delay(20);
    }
    saveToCrossbuf();
}

// ═══════════════════════════════════════════════════════════════════════
//  SPLASH 1+2 — Titre et version sur fond sous-marin animé
//  !! NE PAS MODIFIER — validé et parfait !!
// ═══════════════════════════════════════════════════════════════════════

// Pré-rendu du texte titre dans textbuf (fond noir, texte blanc)
void renderSplash12ToTextbuf() {
    uint16_t *save = framebuf; framebuf = textbuf;
    for (uint32_t i = 0; i < (uint32_t)LAND_W*LAND_H; i++) textbuf[i] = COL_BLACK;
    fbDrawTextCenteredFS(10,  "G   f   r   e   d",       COL_LIGHT_GREY, &FreeSerifBoldItalic24pt7b);
    fbDrawTextCenteredFS(180, "PPO2 Monitor",             COL_LIGHT_GREY, &FreeSerifBoldItalic18pt7b);
    fbDrawTextCenteredFS(215, "Version 5.14.3 — juillet 2026", COL_LIGHT_GREY, &FreeSerifBoldItalic12pt7b);
    framebuf = save;
}

// Affichage du texte pré-rendu avec zoom et alpha sur fond sous-marin
void drawSplash12Zoomed(float scale, uint8_t alphaG) {
    fbCopyFond();
    fbRectAlpha(0, 0, LAND_W, LAND_H, COL_BLACK, 80);
    if (scale <= 0.0f || alphaG == 0) return;
    int fw = (int)(LAND_W*scale), fh = (int)(LAND_H*scale);
    if (fw < 1) fw = 1; if (fh < 1) fh = 1;
    int ox = (LAND_W-fw)/2, oy = (LAND_H-fh)/2;
    uint32_t src_y_step = ((uint32_t)LAND_H << 16) / fh;
    uint32_t src_x_step = ((uint32_t)LAND_W << 16) / fw;
    for (int sy = 0; sy < fh; sy++) {
        int fy = oy+sy; if (fy < 0 || fy >= LAND_H) continue;
        int ty = ((uint32_t)sy * src_y_step) >> 16;
        uint16_t *rowSrc = &textbuf[ty*LAND_W];
        uint16_t *rowDst = &framebuf[fy*LAND_W];
        for (int sx = 0; sx < fw; sx++) {
            int fx = ox+sx; if (fx < 0 || fx >= LAND_W) continue;
            uint16_t col = rowSrc[((uint32_t)sx * src_x_step) >> 16];
            if (col != COL_BLACK) rowDst[fx] = blend565(rowDst[fx], col, alphaG);
        }
    }
}

void showSplash12() {
    renderSplash12ToTextbuf();
    for (int i = 0; i < 30; i++) {
        float t = (float)i/29.0f, ease = easeOut(t);
        drawSplash12Zoomed(0.05f+ease*0.95f, (uint8_t)min(255.0f,t*2.8f*255.0f));
        if (i < 15) {
            uint8_t b = (uint8_t)((i*255)/14);
            uint32_t n = (uint32_t)LAND_W*LAND_H;
            for (uint32_t j = 0; j < n; j++) framebuf[j] = blend565(crossbuf[j], framebuf[j], b);
        }
        flushToDisplay(); delay(41);
    }
    renderSplash12ToTextbuf();
    drawSplash12Zoomed(1.0f, 255); flushToDisplay(); delay(2000);
    for (int i = 19; i >= 0; i--) {
        float t = (float)i/19.0f, ease = easeOut(t);
        drawSplash12Zoomed(0.05f+ease*0.95f, (uint8_t)min(255.0f,t*2.8f*255.0f));
        flushToDisplay(); delay(20);
    }
    saveToCrossbuf();
}

// ═══════════════════════════════════════════════════════════════════════
//  SPLASH 3 — Vérification cellules O2 et batterie (E3)
//  !! NE PAS MODIFIER — validé et parfait !!
//
//  Affiche mV C1/C2 avec sprite OK/KO animé (dandinement)
//  Remplit g_c1, g_c2, g_bat_v, g_bat_pct pour E4
// ═══════════════════════════════════════════════════════════════════════

// Colonnes de E3 (différentes de E4)
#define COL1_L   0
#define COL1_R  185
#define COL2_L  186
#define COL2_R  269
#define COL3_L  270
#define COL3_R  455

// Icône batterie AAA-proportion avec niveau de remplissage coloré
void drawBatteryAAA(int cx, int y, int w, int h, int pct, uint16_t fillColor) {
    int x = cx-w/2;
    fbRect(x, y,     w, h,  COL_BLACK);   // fond
    fbRect(x, y,     w, 2,  COL_WHITE);   // bord haut
    fbRect(x, y+h-2, w, 2,  COL_WHITE);   // bord bas
    fbRect(x, y,     2, h,  COL_WHITE);   // bord gauche
    fbRect(x+w-2, y, 2, h,  COL_WHITE);   // bord droit
    fbRect(x+(w-w/3)/2, y-5, w/3, 5, COL_WHITE);  // borne +
    int fillH = (int)((h-6) * pct / 100.0f);
    if (fillH > 0) fbRect(x+3, y+h-3-fillH, w-6, fillH, fillColor);
}

// ═══════════════════════════════════════════════════════════════════════
//  E3 — bandeau "pense-bête" défilant en continu (rouge, bas d'écran)
//  Bande semi-transparente + texte qui rentre par la droite et sort à
//  gauche en boucle. Appelé à chaque frame avec t = secondes écoulées.
// ═══════════════════════════════════════════════════════════════════════
#define E3_TICKER_TEXT   "DON'T FORGET CALIBRATE !"
#define E3_TICKER_Y      222   // → baseline visuel réel ≈ 276 (bas d'écran)
#define E3_TICKER_SPEED  120.0f // px/seconde — assez rapide pour boucler dans les 5s de E3
#define COL_TICKER_BLUE  0x1C9F // bleu vif, lisible sur fond noir (pas de rouge en trop)

void drawE3Ticker(float t) {
    fbRectAlpha(0, 258, LAND_W, 22, COL_BLACK, 160);   // bande de contraste
    int tw = textWidthFS(E3_TICKER_TEXT, &FreeSansBold12pt7b);
    float cycle = (float)(tw + LAND_W);
    float phase = fmodf(t * E3_TICKER_SPEED, cycle);
    int x = LAND_W - (int)phase;
    fbTextLeft(x, E3_TICKER_Y, E3_TICKER_TEXT, COL_TICKER_BLUE, &FreeSansBold12pt7b);
}

void showSplash3(float c1_mv, float c2_mv, float bat_v) {
    // Plage de contrôle E3 : FIXE, 8-13mV — plage relevée À L'AIR par Fred
    // sur sa propre plaquette de contrôle (photo du 13/07/2026), PAS mise à
    // l'échelle du FiO2 courant. E3 tourne toujours pendant l'allumage à
    // l'air (pratique réelle : SW + GfredDream allumés ensemble à l'air,
    // AVANT les lavages O2) — la mise à l'échelle FiO2 tentée en v4.6.2
    // cassait ce cas précis (déclarait KO à tort dès que FiO2 était réglé
    // sur 0.98 en prévision des lavages). Revenu en arrière v4.6.5.
    // ── v5.13.0 : E3 PUREMENT INFORMATIF ──────────────────────────────
    // Refonte (décision Fred 24/07). E3 n'est plus une barrière : il MESURE
    // et AFFICHE, il ne verrouille rien. Un rallumage en cours de session
    // (boucle pleine d'O2, de nitrox ou d'air) doit toujours retrouver la
    // PPO2 issue de la dernière calibration — comme le Shearwater, qui n'a
    // aucune barrière au démarrage.
    //
    // Chaque cellule reçoit une COULEUR selon la PPO2 qu'elle mesure (via la
    // calibration, si exploitable) — pas selon une plage mV supposée d'un gaz
    // qu'on ne connaît pas :
    //   VERT   PPO2 cohérente avec l'air (~0.16-0.30) → allumage nominal
    //   ORANGE PPO2 >= 0.16 mais hors plage air → O2/nitrox dans la boucle
    //   ROUGE  PPO2 < 0.16 (non respirable en surface) OU cellule qui ne
    //          produit pas de signal exploitable (hors 2-95mV)
    // Le seuil 0.16 vient de Fred : sous 0.16 bar, le mélange n'est pas
    // respirable en surface (on ponte alors sur un gaz externe en profondeur).
    // AUCUN de ces états ne bloque : E4 démarre normalement. AL_DEAD ne
    // subsiste que pour le cas matériel pur (les 2 cellules hors plage vitale
    // = débranchées/mortes), traité plus loin dans setup().
    bool  c1_live = (c1_mv >= CELL_MV_LIVE_MIN && c1_mv <= CELL_MV_LIVE_MAX);
    bool  c2_live = (c2_mv >= CELL_MV_LIVE_MIN && c2_mv <= CELL_MV_LIVE_MAX);
    // PPO2 mesurée — n'a de sens que si la calibration est exploitable.
    bool  calUsable = c1CalOk() && c2CalOk();
    float p1 = calUsable ? (c1_mv / g_calib_c1) * g_fio2_ref * mbarFactor() : -1.0f;
    float p2 = calUsable ? (c2_mv / g_calib_c2) * g_fio2_ref * mbarFactor() : -1.0f;

    // Couleur par cellule. Sans calibration exploitable, on ne peut pas juger
    // la PPO2 : on retombe sur la plage air mV historique comme repère visuel.
    auto cellColor = [](bool live, float ppo2, float mv) -> uint16_t {
        if (!live) return COL_RED;                       // pas de signal exploitable
        if (ppo2 < 0.0f)                                 // pas de calib → repère mV air
            return (mv >= CELL_MV_MIN && mv <= CELL_MV_MAX) ? COL_GREEN : COL_ORANGE;
        if (ppo2 < PPO2_BREATHABLE_MIN) return COL_RED;  // non respirable en surface
        if (ppo2 <= AIR_PPO2_MAX)       return COL_GREEN; // cohérent avec l'air
        return COL_ORANGE;                               // O2/nitrox dans la boucle
    };
    uint16_t c1_flash = cellColor(c1_live, p1, c1_mv);
    uint16_t c2_flash = cellColor(c2_live, p2, c2_mv);

    // Ligne du bas : la PPO2 mesurée (ou les mV si pas de calibration).
    char c1_txt[12], c2_txt[12];
    if (p1 >= 0.0f) snprintf(c1_txt, sizeof(c1_txt), "%.2f", p1);
    else            snprintf(c1_txt, sizeof(c1_txt), "%.1fmV", c1_mv);
    if (p2 >= 0.0f) snprintf(c2_txt, sizeof(c2_txt), "%.2f", p2);
    else            snprintf(c2_txt, sizeof(c2_txt), "%.1fmV", c2_mv);

    bool c1_ok = c1_live, c2_ok = c2_live;
    int bat_pct = batteryPercent(bat_v);   // courbe LiPo réelle (v4.2)
    uint16_t bat_col = bat_pct>=50 ? COL_GREEN : bat_pct>=25 ? COL_YELLOW :
                       bat_pct>=10 ? COL_ORANGE : COL_RED;
    int bcx = (COL2_L+COL2_R)/2;
    char buf[16];
    char checkLabel[64];
    // Label = plage attendue (8-13mV), pas le FiO2 configuré — le check est
    // toujours fait à l'air dans la pratique réelle, donc le FiO2 réglé pour
    // les lavages O2 à venir n'a rien à voir ici. Reprend directement la
    // plaquette de contrôle perso de Fred (idée suggérée le 13/07). v4.6.5.
    // Titre : rappelle la plage air de référence (repère, plus un verdict).
    snprintf(checkLabel, sizeof(checkLabel), "Controle cellules  -  Air : %.0f-%.0fmV",
             CELL_MV_MIN, CELL_MV_MAX);

    // Transférer l'état E3 vers les variables globales pour E4
    g_c1      = { c1_mv, 0.0f, c1_ok };
    g_c2      = { c2_mv, 0.0f, c2_ok };
    g_bat_v   = bat_v;
    g_bat_pct = bat_pct;

    // Pré-rendu du fond statique dans textbuf (une seule fois pour performance)
    {
        uint16_t *save = framebuf; framebuf = textbuf;
        fbCopyFond();
        fbRectAlpha(0, 0, LAND_W, LAND_H, COL_BLACK, 120);
        fbDrawTextCenteredFS(5, checkLabel, COL_ORANGE, &FreeSerifBoldItalic18pt7b);
        fbDrawTextColCenteredFS(COL1_L, COL1_R, 60, "Cell 1", COL_LIGHT_GREY, &FreeSansBold12pt7b);
        snprintf(buf, sizeof(buf), "%.1fmV", c1_mv);
        fbDrawTextColCenteredFS(COL1_L, COL1_R, 120, buf, c1_flash, &FreeSansBold24pt7b);
        fbDrawTextColCenteredFS(COL3_L, COL3_R, 60, "Cell 2", COL_LIGHT_GREY, &FreeSansBold12pt7b);
        snprintf(buf, sizeof(buf), "%.1fmV", c2_mv);
        fbDrawTextColCenteredFS(COL3_L, COL3_R, 120, buf, c2_flash, &FreeSansBold24pt7b);
        drawBatteryAAA(bcx, 140, 30, 60, bat_pct, bat_col);
        snprintf(buf, sizeof(buf), "%.2fV", bat_v);
        fbDrawTextColCenteredFS(COL2_L-15, COL2_R+15, 180, buf, COL_LIGHT_GREY, &FreeSansBold12pt7b);
        // v5.10.0 — référence de pression au BOOT : c'est le moment où l'on
        // compare avec le Shearwater. Icône + valeur. Colonne centrale, zone
        // libre entre le bandeau de titre (glyphes ~30-59) et la batterie
        // (140-200 en pixels réels) : icône 70-94, valeur 100-117.
        drawPressureRef(bcx, 70, COL2_L-15, COL2_R+15, 100);
        framebuf = save;
    }

    // Fonction locale : compose le fond + les deux verdicts animés (texte, v4.2)
    auto drawFrame = [&](int xoff1, int xoff2) {
        memcpy(framebuf, textbuf, (size_t)LAND_W*LAND_H*2);
        fbDrawTextColCenteredFS(COL1_L+xoff1, COL1_R+xoff1, 180,
            c1_txt, c1_flash, &FreeSansBold24pt7b);
        fbDrawTextColCenteredFS(COL3_L+xoff2, COL3_R+xoff2, 180,
            c2_txt, c2_flash, &FreeSansBold24pt7b);
    };

    // Fondu enchaîné depuis splash12 → E3 (les fondus E1-E2-E3 sont CONSERVÉS)
    for (int i = 0; i <= 25; i++) {
        uint8_t a = (uint8_t)((i*255)/25);
        uint32_t n = (uint32_t)LAND_W*LAND_H;
        for (uint32_t j = 0; j < n; j++) framebuf[j] = blend565(crossbuf[j], textbuf[j], a);
        if (a > 100) {
            fbDrawTextColCenteredFS(COL1_L, COL1_R, 180, c1_txt, c1_flash, &FreeSansBold24pt7b);
            fbDrawTextColCenteredFS(COL3_L, COL3_R, 180, c2_txt, c2_flash, &FreeSansBold24pt7b);
        }
        flushToDisplay(); delay(20);
    }

    // Animation dandinement ~5s @ 24 FPS (allongé pour laisser le temps au bandeau de défiler)
    uint32_t tstart = millis();
    while (millis()-tstart < 5000) {
        float t = (float)(millis()-tstart) / 1000.0f;
        drawFrame((int)(10.0f*sinf(t*8.0f)), (int)(10.0f*sinf(t*8.0f+3.14159f)));
        drawE3Ticker(t);   // pense-bête rouge défilant
        flushToDisplay(); delay(41);
    }

    // v4.2 : plus de fondu de sortie — coupe sèche E3 → E4
    drawFrame(0, 0);
    flushToDisplay();
}

// ═══════════════════════════════════════════════════════════════════════
//  COULEURS PPO2 — rEvodream P5
//  Source : manuel officiel rEvodream P/P5 + chart V4
//  3 couleurs UNIQUEMENT : Orange / Vert / Rouge — zéro jaune !
//  Correspondance exacte avec le HUD physique monté côte à côte
// ═══════════════════════════════════════════════════════════════════════

// Couleur du CHIFFRE PPO2 C1/C2 (= LED dominante HUD)
uint16_t ppo2CellColor(float ppo2) {
    switch (g_hud_mode) {
        case 0: // 4P CCR : vert 0.5–1.40, orange <0.5, rouge >1.40
            if (ppo2 < 0.5f)  return COL_ORANGE;
            if (ppo2 < 1.40f) return COL_GREEN;
            return COL_RED;
        case 1: // 5P Smithers : vert 0.5–1.10
            if (ppo2 < 0.5f)  return COL_ORANGE;
            if (ppo2 < 1.10f) return COL_GREEN;
            return COL_RED;
        case 2: // 6P SCR : vert 0.5–1.45
            if (ppo2 < 0.5f)  return COL_ORANGE;
            if (ppo2 < 1.45f) return COL_GREEN;
            return COL_RED;
        default: return COL_WHITE;
    }
}

// Flash stroboscope C1/C2 : zones de danger extrême uniquement
bool ppo2NeedsFlash(float ppo2) { return (ppo2 < 0.3f || ppo2 >= 1.55f); }

// Vitesse des pulses selon urgence (utilisé par ppo2PulsePeriodMs si nécessaire)
uint32_t ppo2PulsePeriodMs(float ppo2) {
    switch (g_hud_mode) {
        case 0:
            if (ppo2 < 0.3f || ppo2 >= 1.65f)              return 300;
            if (ppo2 < 0.5f || (ppo2>=1.55f&&ppo2<1.65f))  return 600;
            if (ppo2 < 0.7f || (ppo2>=1.45f&&ppo2<1.55f))  return 1000;
            return 2000;
        case 1: if (ppo2 < 0.5f || ppo2 >= 1.55f) return 400; return 2000;
        case 2: if (ppo2 < 0.25f || ppo2 >= 1.55f) return 300; return 1500;
        default: return 2000;
    }
}

// ═══════════════════════════════════════════════════════════════════════
//  HUD PHYSIQUE — 3 LEDs superposées (rouge IO3 haut / verte IO5 milieu /
//  orange IO6 bas) — copie conforme du chart rEvodream P5 (la bible) :
//  la verte est CONTINUE dans sa fenêtre, l'orange PULSE dans les zones
//  basses, la rouge PULSE dans les zones hautes, silence en zone parfaite.
//  Les rythmes sont réutilisés par votingDigitColor() → synchronisation
//  garantie avec le chiffre voting à l'écran ET le rEvodream original.
// ═══════════════════════════════════════════════════════════════════════
// ═══════════════════════════════════════════════════════════════════════
//  hudPulseOn — rythmes des LEDs HUD, pilotés par phase millis() DIRECTE
//  (jamais par échantillonnage de la courbe écran : 300ms de pulse lus
//  toutes les 41ms de frame = battement d'aliasing → rythme irrégulier).
//
//  CHRONOMÉTRAGE RÉEL relevé par Fred sur son rEvodream P5 :
//  • PPO2 0.98 (zone 0.7-1.0 "1 pulse court"), mesuré 11/07 en ralenti 1/8 :
//      ON ~320ms, période 1.89s — SUSPECT (voir ci-dessous), pas encore
//      re-vérifié en vitesse réelle.
//  • PPO2 0.21 (zone <0.3 orange / >=1.65 rouge "rapide"), REMESURÉ 13/07 en
//    VITESSE RÉELLE (tracking pixel anti-dérive, 2 clips indépendants) :
//      SALVE DE 7 PULSES — ON ~260ms / OFF ~241ms, cycle 501ms,
//      puis PAUSE ~660ms → super-cycle ~3.91s.
//  • Caisson pression 13/07 (montée >1.65 puis purge lente, PPO2 réel lu à
//    l'écran du rEvodream pour identifier chaque zone sans ambiguïté) :
//    - 1.55-1.65 "2 pulses rouge" — MESURÉ (3 paires indépendantes) :
//        2× pulse ~984ms séparés d'un écart court ~256ms, groupe ~3.92s
//    - 1.45-1.55 "1 pulse rouge" — MESURÉ (5 cycles stables, ~19s) :
//        pulse ~988ms, période ~3.783s
//    - 1.40-1.45 "1 pulse très court rouge" : PAS DIRECTEMENT MESURÉ (la
//      zone a été traversée trop vite pendant la purge) — reste ~estimé,
//      mais aligné sur la valeur symétrique mesurée côté orange (voir juste
//      en dessous) plutôt que sur l'ancienne supposition à 320ms.
//    - 1.0-1.25 "1 pulse très court orange" — MESURÉ (~100s stables,
//      ~28 cycles, PPO2 confirmé "1.20" lu à l'écran) :
//        pulse ~267ms, période ~3.787s
//  Symétrie orange/rouge : posée comme hypothèse historique (jamais prise en
//  défaut sur les zones mesurées des deux côtés — rapide et très-court
//  collent des deux côtés), donc appliquée aussi à 0.3-0.5 (pas mesurable
//  au caisson, trop aléatoire selon Fred) et à 1.40-1.45 (traversée trop
//  vite). 0.5-0.7 orange non plus mesuré, mais aligné sur le 1.45-1.55
//  rouge mesuré par la même hypothèse.
//
//  MISE À JOUR 17/07 — caisson étanchéifié, 10 clips filmés à L'AIR (0 à
//  7 bar), vitesse réelle, chaque zone du chart directement ciblée. PLUS
//  AUCUNE case posée par hypothèse de symétrie : chaque zone a maintenant
//  sa propre mesure, orange ET rouge.
//    0.26/1.68 (rapide)        : confirme le caisson O2 (7 pulses, ~500ms,
//                                super-cycle ~3.9-3.95s)
//    0.41 (2 pulses orange)    : ON total/salve ~1683ms, super-cycle ~3.93s
//    1.60 (2 pulses rouge)     : confirme le caisson (2×~1009-1043ms,
//                                écart ~219-252ms, super-cycle ~3.93s)
//    0.59 (1 long orange)      : ON total/salve ~1052ms, période ~3.81s
//    1.50 (1 pulse rouge)      : confirme le caisson (~993-1043ms/3.81s)
//    0.85 (court orange)       : ON total/salve ~555ms, période ~3.81s —
//                                CORRIGE l'ancien 320ms/1.9s du ralenti,
//                                qui était bien faux comme suspecté
//    1.08 (très court orange)  : confirme le caisson (~207-267ms/~3.8s)
//    1.42 (très court rouge)   : PREMIÈRE mesure directe (252-286ms/3.81s)
//                                — confirme enfin la symétrie avec 1.0-1.25
//    1.30 (silence)            : confirme (0 transition sur 20s)
//  Note méthode : dans ce caisson (bulles/condensation), le seuil ON/OFF
//  frame-à-frame est bruité (micro-coupures dans un pulse réel) — la
//  durée fiable est le temps ON CUMULÉ sur toute la fenêtre du groupe,
//  pas le premier front détecté isolément.
// ═══════════════════════════════════════════════════════════════════════

// Salve rapide (<0.3 orange / >=1.65 rouge) — MESURÉ (caisson O2 + air)
#define HUD_FAST_SUPERCYCLE_MS  3910   // salve+pause (3.90-3.95s selon les clips)
#define HUD_FAST_PULSE_CYCLE_MS  501   // cycle intra-salve (constant sur 4 clips)
#define HUD_FAST_PULSE_ON_MS     260   // ON par pulse (mesuré 235-286ms)
#define HUD_FAST_BURST_PULSES      7   // confirmé sur 9 salves indépendantes

// "2 pulses" (0.3-0.5 orange / 1.55-1.65 rouge) — MESURÉ des deux côtés
#define HUD_2P_GROUP_MS   3920    // groupe (2 pulses + pause), mesuré ~3.92-3.93s
#define HUD_2P_PULSE_ON_MS 984    // ON par pulse, mesuré 968-1043ms
#define HUD_2P_GAP_MS       256   // écart court entre les 2 pulses du groupe

// "1 pulse" (0.5-0.7 orange / 1.45-1.55 rouge) — MESURÉ des deux côtés
#define HUD_1P_CYCLE_MS   3800    // période, mesuré 3.78-3.83s (moyenne 3.80s)
#define HUD_1P_PULSE_ON_MS 1010   // ON, mesuré 968-1052ms

// "court" (0.7-1.0 UNIQUEMENT — pas de zone rouge équivalente dans le chart)
// MESURÉ 17/07 en vitesse réelle : corrige l'ancien 320ms/1.9s du ralenti
#define HUD_SHORT_CYCLE_MS 3800   // période, même famille que les zones voisines
#define HUD_SHORT_PULSE_ON_MS 555 // ON total mesuré (méthode temps cumulé)

// "très court" (1.0-1.25 orange / 1.40-1.45 rouge) — MESURÉ des deux côtés
#define HUD_VS_CYCLE_MS   3800    // période, mesuré 3.78-3.82s
#define HUD_VS_PULSE_ON_MS 265    // ON, mesuré 207-286ms selon les clips

bool hudPulseOn(float p) {
    if (p >= 1.25f && p < 1.40f) return false;        // zone parfaite : silence

    // "Rapide" (<0.3 et >1.65) — MESURÉ : salve de 7 pulses puis pause
    if (p < 0.3f || p >= 1.65f) {
        uint32_t ts = millis() % HUD_FAST_SUPERCYCLE_MS;
        // Fin de la salve = 6 cycles complets + le ON du 7e pulse
        uint32_t burst_span = (HUD_FAST_BURST_PULSES - 1) * HUD_FAST_PULSE_CYCLE_MS
                             + HUD_FAST_PULSE_ON_MS;
        if (ts >= burst_span) return false;           // pause entre salves
        return (ts % HUD_FAST_PULSE_CYCLE_MS) < HUD_FAST_PULSE_ON_MS;
    }

    // "2 pulses" — MESURÉ des deux côtés : 2× ~984ms séparés d'un écart
    // ~256ms, puis silence jusqu'à la fin du groupe (~3.92s)
    if ((p>=0.3f&&p<0.5f) || (p>=1.55f&&p<1.65f)) {
        uint32_t tg = millis() % HUD_2P_GROUP_MS;
        if (tg < HUD_2P_PULSE_ON_MS) return true;                       // 1er pulse
        uint32_t t2 = HUD_2P_PULSE_ON_MS + HUD_2P_GAP_MS;
        return (tg >= t2) && (tg < t2 + HUD_2P_PULSE_ON_MS);             // 2e pulse
    }

    // "1 pulse" — MESURÉ des deux côtés : ~1010ms ON / ~3.8s
    if ((p>=0.5f&&p<0.7f) || (p>=1.45f&&p<1.55f))
        return (millis() % HUD_1P_CYCLE_MS) < HUD_1P_PULSE_ON_MS;

    // "court" (0.7-1.0 uniquement) — MESURÉ 17/07, remplace le 320ms/1.9s
    // du ralenti (confirmé faux)
    if (p>=0.7f&&p<1.0f)
        return (millis() % HUD_SHORT_CYCLE_MS) < HUD_SHORT_PULSE_ON_MS;

    // "très court" — MESURÉ des deux côtés (1.0-1.25 ET 1.40-1.45,
    // symétrie enfin confirmée directement) : ~265ms ON / ~3.8s
    if ((p>=1.0f&&p<1.25f) || (p>=1.40f&&p<1.45f))
        return (millis() % HUD_VS_CYCLE_MS) < HUD_VS_PULSE_ON_MS;

    return false;
}

// Seuils de zone HUD par mode — extrait de hudUpdate() en v5.1.0 pour être
// partagé avec votingDigitColor() (l'écran voting doit être un miroir EXACT
// du HUD physique, pas une approximation séparée).
void hudZoneThresholds(float &g_lo, float &g_hi, float &o_below, float &r_from) {
    switch (g_hud_mode) {
        // 5P "Smithers modifié" — APPROXIMATION : le vrai code Smithers compte
        // les pulses (N pulses = N×0.1 bar d'écart à 1.0) — TODO nouveau chat
        case 1:  g_lo=0.5f;  g_hi=1.10f; o_below=0.95f; r_from=1.10f; break;
        // 6P SCR — CORRIGÉ v4.3.0 selon manuel P5 : vert 0.25-1.55 (pas
        // 0.5-1.45), orange pulse 0.25-0.5, rouge dès 1.45. Approximation
        // connue : 0.25-0.3 flashera "rapide" au lieu d'un pulse simple.
        case 2:  g_lo=0.25f; g_hi=1.55f; o_below=0.50f; r_from=1.45f; break;
        // 4P CCR (défaut Fred) — conforme chart rEvodream P5 V4
        default: g_lo=0.5f;  g_hi=1.55f; o_below=1.25f; r_from=1.40f; break;
    }
}

void hudUpdate(float ppo2) {
    float g_lo, g_hi, o_below, r_from;
    hudZoneThresholds(g_lo, g_hi, o_below, r_from);
    // Pulse net par phase directe (v4.2.2) — régulier quelle que soit la cadence frames
    bool blink = hudPulseOn(ppo2);
    uint8_t duty = (uint8_t)((uint16_t)g_hud_brightness * 255 / 100);  // v4.5.0 : PWM
    ledcWrite(PIN_LED_GREEN,  (ppo2 >= g_lo && ppo2 < g_hi) ? duty : 0);
    ledcWrite(PIN_LED_ORANGE, (ppo2 <  o_below && blink)    ? duty : 0);
    ledcWrite(PIN_LED_RED,    (ppo2 >= r_from  && blink)    ? duty : 0);
}

void hudAllOff() {
    ledcWrite(PIN_LED_RED,    0);
    ledcWrite(PIN_LED_GREEN,  0);
    ledcWrite(PIN_LED_ORANGE, 0);
}

// v5.13.0 — flash de TRANSITION : 3 impulsions des 3 LED simultanément.
// Signale un CHANGEMENT d'état d'une cellule (OK↔ERR), dans les deux sens :
// "quelque chose vient de changer, regarde l'écran". BLOQUANT à dessein
// (~600ms, décision Fred) : un changement d'état mérite d'interrompre le
// pattern normal — c'est justement le message. Respecte la luminosité HUD.
void hudTransitionFlash() {
    uint8_t duty = (uint8_t)((uint16_t)g_hud_brightness * 255 / 100);
    for (int i = 0; i < 3; i++) {
        ledcWrite(PIN_LED_RED, duty); ledcWrite(PIN_LED_GREEN, duty); ledcWrite(PIN_LED_ORANGE, duty);
        delay(90);
        hudAllOff();
        delay(110);
    }
}

// Nom du mode pour affichage dans E4
const char* hudModeName() {
    switch (g_hud_mode) { case 0:return "CCR"; case 1:return "SMT"; case 2:return "SCR"; default:return "?"; }
}

// ═══════════════════════════════════════════════════════════════════════
//  CADRE ARRONDI — bordure coins ronds avec alpha
//  Utilisé pour encadrer la zone voting selon les pulses rEvodream
//  x/y = coin supérieur gauche, w/h = dimensions, r = rayon coins
//  thick = épaisseur du trait, c = couleur, a = alpha 0-255
// ═══════════════════════════════════════════════════════════════════════
void fbRoundRectAlpha(int x, int y, int w, int h, int r, int thick, uint16_t c, uint8_t a) {
    // Côtés droits haut/bas et gauche/droite
    for (int t = 0; t < thick; t++) {
        for (int i = x+r; i < x+w-r; i++) {
            if (i>=0&&i<LAND_W) {
                if (y+t>=0&&y+t<LAND_H)         framebuf[(y+t)*LAND_W+i]     = blend565(framebuf[(y+t)*LAND_W+i],c,a);
                if (y+h-1-t>=0&&y+h-1-t<LAND_H) framebuf[(y+h-1-t)*LAND_W+i] = blend565(framebuf[(y+h-1-t)*LAND_W+i],c,a);
            }
        }
        for (int j = y+r; j < y+h-r; j++) {
            if (j>=0&&j<LAND_H) {
                if (x+t>=0&&x+t<LAND_W)         framebuf[j*LAND_W+(x+t)]     = blend565(framebuf[j*LAND_W+(x+t)],c,a);
                if (x+w-1-t>=0&&x+w-1-t<LAND_W) framebuf[j*LAND_W+(x+w-1-t)] = blend565(framebuf[j*LAND_W+(x+w-1-t)],c,a);
            }
        }
    }
    // 4 coins arrondis par algorithme de cercle
    for (int cy = -r; cy <= r; cy++) for (int cx = -r; cx <= r; cx++) {
        int d2 = cx*cx+cy*cy, rout = r*r, rin = (r-thick)*(r-thick);
        if (d2 <= rout && d2 >= rin) {
            int coords[4][2] = {
                {x+r+cx,   y+r+cy},    {x+w-r-1+cx, y+r+cy},
                {x+r+cx,   y+h-r-1+cy},{x+w-r-1+cx, y+h-r-1+cy}
            };
            for (int k = 0; k < 4; k++) {
                int px = coords[k][0], py = coords[k][1];
                if (px>=0&&px<LAND_W&&py>=0&&py<LAND_H)
                    framebuf[py*LAND_W+px] = blend565(framebuf[py*LAND_W+px], c, a);
            }
        }
    }
}

// ═══════════════════════════════════════════════════════════════════════
//  COURBE DE FLASH STROBOSCOPE
//  Pic rapide (20% du temps) + long creux sombre (80%)
//  t_norm = 0.0 à 1.0 (phase normalisée dans la période)
//  Retourne 0-255 : bref flash lumineux puis long noir
// ═══════════════════════════════════════════════════════════════════════
uint8_t flashCurve(float t) {
    if (t < 0.2f) { float u=t/0.2f; return (uint8_t)(u*u*255.0f); }     // montée quadratique rapide
    float u=(t-0.2f)/0.8f; return (uint8_t)((1.0f-u)*(1.0f-u)*255.0f);  // descente parabolique lente
}

// Assombrit une couleur RGB565 par un facteur alpha (0=noir, 255=couleur pleine)
uint16_t dimColor(uint16_t col, uint8_t a) {
    if (a == 255) return col;
    if (a == 0)   return COL_BLACK;
    uint8_t r=(((col>>11)&31)*a)>>8, g=(((col>>5)&63)*a)>>8, b=((col&31)*a)>>8;
    return (r<<11)|(g<<5)|b;
}

// ═══════════════════════════════════════════════════════════════════════
//  PULSES CADRE VOTING — timing précis rEvodream P5
//
//  Reproduit EXACTEMENT le comportement des LEDs HUD physiques
//  (important : les deux HUDs sont côte à côte sur le DSV)
//
//  Mode 4P CCR (source : manuel rEvodream P/P5 officiel) :
//  v5.1.1 — REVU avec Fred : le chiffre passait de orange à VERT entre deux
//  pulses même très bas (0.21) — faux (pas de vert là-bas), et le faire
//  passer au NOIR à la place rendrait le chiffre illisible la plupart du
//  temps sur les pulses courts (120ms/1.9s). Solution : on INVERSE qui
//  clignote. Le CHIFFRE reste fixe (toujours lisible) : vert tant qu'on
//  est dans la fenêtre verte du HUD, orange en dessous, rouge au-dessus —
//  jamais de flash sur le chiffre lui-même. C'est le CADRE qui reprend le
//  clignotement exact du HUD (mêmes seuils o_below/r_from, même cadence
//  hudPulseOn) : invisible en zone silence (1.25-1.40), sinon il pulse en
//  orange ou rouge en plus du chiffre — qui, lui, ne bouge pas.
// ═══════════════════════════════════════════════════════════════════════
uint16_t votingDigitColor(float ppo2) {
    float g_lo, g_hi, o_below, r_from;
    hudZoneThresholds(g_lo, g_hi, o_below, r_from);
    if (ppo2 < g_lo) return COL_ORANGE;
    if (ppo2 >= g_hi) return COL_RED;
    return COL_GREEN;
}

// Couleur du CADRE voting À CET INSTANT (0 = invisible) — mêmes seuils et
// même cadence que les LEDs orange/rouge du HUD physique (hudPulseOn()).
uint16_t votingFrameColor(float ppo2) {
    float g_lo, g_hi, o_below, r_from;
    hudZoneThresholds(g_lo, g_hi, o_below, r_from);
    bool blink = hudPulseOn(ppo2);
    if (ppo2 < o_below && blink) return COL_ORANGE;
    if (ppo2 >= r_from && blink) return COL_RED;
    return 0;   // silence, ou pulse en phase OFF
}

// ═══════════════════════════════════════════════════════════════════════
//  COLONNES ET CADRE VOTING — defines E4
// ═══════════════════════════════════════════════════════════════════════
#define E4_C1L  0       // colonne Cell 1 : x gauche
#define E4_C1R  185     // colonne Cell 1 : x droite
#define E4_VL   186     // colonne Voting : x gauche
#define E4_VR   269     // colonne Voting : x droite
#define E4_C2L  270     // colonne Cell 2 : x gauche
#define E4_C2R  455     // colonne Cell 2 : x droite
#define VF_Y    0       // cadre voting : y haut (géométrie déjà calibrée)
#define VF_H    88      // cadre voting : hauteur
// ── v5.8.0 : colonne centrale E4 réorganisée (demande Fred 24/07) ──────
// Bandes libres constatées avant modif : 88→130 (42px) et 147→195 (48px).
// CCR descend vers la batterie pour dégager la bande haute. Ces 3 valeurs
// sont les SEULES coordonnées déplacées de tout le projet — tout le reste
// (Cell 1/2, mV, PPO2 géants, batterie, volts, OTA/BTH) est intact.
// v5.9.0 — le verdict calibration a migré au droit de chaque label cellule,
// ce qui libère toute la bande 88→195 pour le couple montagne + CCR.
// Recentrage : bande utile 107px (88 → 195, haut de la batterie), groupe =
// montagne 20 + espace 10 + CCR 17 = 47px → marge (107-47)/2 = 30px de part
// et d'autre. Résultat : 30 au-dessus, 10 entre les deux, 30 en dessous.
// Recentrage recalculé pour MTN_H=24 : bande utile 107px (88 → 195, haut de
// la batterie), groupe = 24 + 10 d'espace + 17 de CCR = 51px, donc marge
// (107-51)/2 = 28px de part et d'autre.
#define E4_MTN_Y  116   // icône montagne (config B uniquement) — 116→140
#define E4_CCR_Y  150   // CCR/SMT/SCR — 150→167 (position déjà validée par Fred)

// ── Icône montagne — signale la CONFIG B (pression ≠ 1013) ─────────────
// Tracé vectoriel en scanlines (fbRect 1px) : ~80 octets de code contre
// plusieurs dizaines de ko pour un sprite, et redimensionnable librement.
// Volontairement ABSENTE en config A : son apparition est l'information.
// v5.8.1 — DEUX pics décalés (croquis Fred 24/07) au lieu d'un seul : plus
// lisible en 34px et immédiatement reconnaissable comme un massif. Le pic
// avant est dessiné par-dessus l'arrière dans une teinte atténuée — c'est
// ce contraste qui crée la profondeur et sépare les deux silhouettes.
static void drawPeak(int apex_x, int ytop, int ybase, int halfw,
                     uint16_t body, uint16_t snow) {
    int h = ybase - ytop;
    if (h < 1 || halfw < 1) return;
    for (int r = 0; r < h; r++) {
        int half = (r + 1) * halfw / h;
        if (half < 1) half = 1;
        fbRect(apex_x - half, ytop + r, half * 2, 1, (r < h / 3) ? snow : body);
    }
}

static void drawMountain(int cx, int ytop, int w, int h, uint16_t body, uint16_t snow) {
    int ybase = ytop + h;
    drawPeak(cx - w/8, ytop,       ybase, (w*38)/100, body, snow);               // pic arrière (haut)
    drawPeak(cx + w/5, ytop + h/3, ybase, (w*26)/100, dimColor(body,165), snow); // pic avant (bas)
}

// ── Icône niveau de la mer — signale la CONFIG A (1013 mbar) ───────────
// v5.10.0 — décision Fred 24/07 : une ABSENCE d'icône est indiscernable
// d'une panne. Ne rien afficher en config A ne permettait pas de distinguer
// "je suis au niveau de la mer" de "vieux firmware" ou "rendu raté". Un
// symbole présent dit DEUX choses : quelle référence, et que le firmware est
// vivant et sait où il en est. C'est ce que fait le Shearwater, qui affiche
// "SURF 1013" en clair au lieu de masquer l'info en mode SeaLvl.
// Deux vaguelettes en antiphase, 2 cycles sur la largeur. Le contraste
// plat/relief avec la montagne se lit sans texte ni traduction mentale.
static void drawSeaLevel(int cx, int ytop, int w, int h, uint16_t col) {
    for (int wave = 0; wave < 2; wave++) {
        int base = ytop + h/3 + wave * (h/3);
        for (int i = 0; i < w; i++) {
            float ph = (float)i / (float)w * 6.2832f * 2.0f + (float)wave * 3.1416f;
            int   dy = (int)lroundf(sinf(ph) * ((float)h / 10.0f));
            fbRect(cx - w/2 + i, base + dy, 1, 2, col);
        }
    }
}

// ── Indicateur de référence de pression — point d'entrée des 4 écrans ──
// Config A → vaguelettes en COL_BLUE_DARK (discret : c'est l'état normal,
//            même principe que le "OK" en vert sombre).
// Config B → montagnes en COL_ORANGE plein (l'exception doit sauter aux yeux).
// La valeur chiffrée n'est affichée que sur les écrans de VÉRIFICATION
// (E3/CA1/CA2), là où Fred compare avec le Shearwater. Sur E4, en plongée,
// elle n'apporte rien : la pression a été figée au moment de la calibration
// et ne bouge plus — l'icône suffit à confirmer la référence.
static void drawPressureRef(int cx, int ytop, int xl, int xr, int valueYTop) {
    bool cfgA = (g_mbar_ref == MBAR_DEFAULT);
    if (cfgA) drawSeaLevel(cx, ytop, MTN_W, MTN_H, COL_BLUE_DARK);
    else      drawMountain(cx, ytop, MTN_W, MTN_H, COL_ORANGE, COL_WHITE);
    if (valueYTop >= 0) {
        char vb[16];
        snprintf(vb, sizeof(vb), "%u mb", g_mbar_ref);
        fbTextCenterTop(xl, xr, valueYTop, vb,
                        cfgA ? COL_BLUE_DARK : COL_ORANGE, &FreeSansBold12pt7b);
    }
}

// ═══════════════════════════════════════════════════════════════════════
//  DRAW E4 — frame complète de l'écran principal plongée
//
//  Paramètres :
//    c1_ppo2/c2_ppo2 = PPO2 cellules (bar)
//    c1_mv/c2_mv     = millivolts bruts ADS1115
//    voting          = valeur à afficher au centre (moyenne ou C1 ou C2)
//    bat_v/bat_pct   = tension et pourcentage batterie
//    flash_t         = phase normalisée 0.0-1.0 pour stroboscope C1/C2
// ═══════════════════════════════════════════════════════════════════════
// v5.5.1 — déplacés ici (avant leur 1er usage dans drawE4Frame) : le
// compilateur Arduino ne pré-déclare pas les #define comme il le fait pour
// les fonctions, l'ordre dans le fichier compte pour de vrai.
#define AL_DEAD_BLINK_MS   1100     // période totale du clignotement (texte AL_DEAD)
#define AL_DEAD_BLINK_ON   605      // durée visible dans la période

// v5.5.3 — cadence dédiée du mini-crâne divergence, plus rapide/frénétique
// que le clignotement calme d'AL_DEAD (situation active à surveiller, pas
// figée) : cycle 300ms, moitié visible/moitié invisible.
#define DIVERGENCE_BLINK_MS 300
#define DIVERGENCE_BLINK_ON 150

void drawE4Frame(float c1_ppo2, float c1_mv, float c2_ppo2, float c2_mv,
                 float voting, float bat_v, int bat_pct, float flash_t,
                 bool divergence) {
    fbFill(COL_BLACK);
    char buf[20];

    // Couleurs selon zones rEvodream P5
    uint16_t col1 = ppo2CellColor(c1_ppo2);
    uint16_t col2 = ppo2CellColor(c2_ppo2);
    // v5.1.1 — chiffre voting FIXE (vert/orange/rouge selon fenêtre HUD,
    // jamais de flash dessus) ; le cadre, lui, pulse exactement comme le
    // HUD physique (0 = invisible, silence ou phase OFF du pulse).
    uint16_t colV     = votingDigitColor(voting);
    // v5.5.3 — pendant une divergence, le HUD physique est éteint
    // (hudAllOff()) : le cadre qui le mirroite doit rester cohérent et
    // s'éteindre aussi, sinon il continue de pulser sur une valeur
    // "voting" qui n'a plus de sens (moyenne de 2 cellules pas d'accord).
    uint16_t frameCol = divergence ? 0 : votingFrameColor(voting);

    // Alpha stroboscope C1/C2 : 10% → 100% si zone de danger extrême
    uint8_t fc     = flashCurve(flash_t);
    uint8_t alpha1 = ppo2NeedsFlash(c1_ppo2) ? (uint8_t)(25+(fc*230/255)) : 255;
    uint8_t alpha2 = ppo2NeedsFlash(c2_ppo2) ? (uint8_t)(25+(fc*230/255)) : 255;

    // ── Cadre voting — franc (pas de fondu), pile le rythme HUD ─────
    if (frameCol) {
        fbRectAlpha(E4_VL+6, VF_Y+6, E4_VR-E4_VL-12, VF_H-12, frameCol, 90);      // fond semi-transparent
        fbRoundRectAlpha(E4_VL-8, VF_Y, E4_VR-E4_VL+16, VF_H, 8, 3, frameCol, 255); // bordure pleine
    }

    // ── Labels Cell 1 / Cell 2 — FreeSansBold18pt, baseline y=18 ────
    fbTextLeft( E4_C1L, 18, "Cell 1", COL_BLUE_DARK, &FreeSansBold18pt7b);
    fbTextRight(E4_C2R, 18, "Cell 2", COL_BLUE_DARK, &FreeSansBold18pt7b);

    // ── v5.9.0 : verdict PAR CELLULE, collé à son propre label ───────
    // À DROITE de "Cell 1", à GAUCHE de "Cell 2" : chaque marqueur est
    // physiquement du côté de sa cellule, donc impossible de se tromper de
    // colonne d'un coup d'œil — c'est le point de la demande. Permet de
    // continuer en mode dégradé sur une cellule en sachant laquelle lâcher.
    // Rouge FIXE, jamais clignotant (cf. "sapin de Noël", v5.5.x).
    // v5.9.2 — le "OK" passe de COL_GREEN à COL_DARK_GREEN : une information
    // de NORMALITÉ ne doit pas être l'élément le plus lumineux de l'écran
    // (remarque Fred sur photo réelle). L'œil doit être attiré par ce qui ne
    // va pas. Et c'est déjà ton vocabulaire visuel : OTA/BTH utilisent le
    // même COL_DARK_GREEN pour "opérationnel". Le rouge, lui, reste plein.
    // ERR si : pas de calibration, OU dernière calib échouée (persisté NVS),
    // OU lecture live hors plage / latch de confiance tombé (ex : débranchée).
    //
    // v5.9.1 — DEUX polices, et c'est indispensable :
    //   fLabel (18pt) sert UNIQUEMENT à MESURER la largeur de "Cell 1"/"Cell 2"
    //          pour savoir où commence l'espace libre. Les labels sont dessinés
    //          en 18pt juste au-dessus : mesurer avec une autre police donnerait
    //          une largeur trop courte et le marqueur chevaucherait le label.
    //   fMark  (12pt) est la police de DESSIN du marqueur — la même que CCR
    //          (demande Fred). Bonus : ~40% de largeur en moins, donc plus
    //          aucun risque de mordre sur la colonne voting (x=186).
    // Le même y=18 conserve l'alignement des lignes de base malgré la
    // différence de taille : fbDrawTextFreeSans blitte un canvas de hauteur
    // FIXE dont la ligne de base est à (hauteur-6), indépendamment de la police.
    // v5.11.0 — !c1CalOk() couvre désormais l'absence de calibration ET
    // l'incohérence FiO2/pression, détectée en continu.
    bool c1_bad = !c1CalOk() || g_c1_cal_ko || !g_c1.ok;
    bool c2_bad = !c2CalOk() || g_c2_cal_ko || !g_c2.ok;
    const GFXfont* fLabel = &FreeSansBold18pt7b;   // = police des labels (mesure)
    const GFXfont* fMark  = &FreeSansBold12pt7b;   // = police de CCR (dessin)
    fbTextLeft(E4_C1L + textWidthFS("Cell 1", fLabel) + 14, 18,
               c1_bad ? "ERR" : "OK", c1_bad ? COL_RED : COL_DARK_GREEN, fMark);
    fbTextRight(E4_C2R - textWidthFS("Cell 2", fLabel) - 14, 18,
                c2_bad ? "ERR" : "OK", c2_bad ? COL_RED : COL_DARK_GREEN, fMark);

    // ── Label voting — toujours "Voting" (v4.5.0 : plus d'alternance ────
    // Cell1/Cell2 texte — décision Fred 12/07 : "on garde uniquement le
    // voting", l'échec cellule reste visible via le "ERR" géant existant)
    const char* vlabel = "Voting";
    fbTextCenterTop(E4_VL, E4_VR, 10, vlabel, COL_BLUE_DARK, &FreeSerifBoldItalic12pt7b);

    // ── Mode CCR/SMT/SCR — descendu en y=E4_CCR_Y (v5.8.0) ──────────
    fbTextCenterTop(0, LAND_W, E4_CCR_Y, hudModeName(), COL_BLUE_DARK, &FreeSansBold12pt7b);

    // ── Référence de pression — icône SEULE (pas de valeur en plongée) ─
    drawPressureRef((E4_VL+E4_VR)/2, E4_MTN_Y, 0, 0, -1);

    // ── Chiffre voting — FreeSerifBoldItalic24pt, y_top=40 ───────────
    // v5.5.0 — divergence C1/C2 : mini-crâne clignotant à la place du
    // chiffre. Jamais de valeur calculée trompeuse quand on ne sait pas
    // laquelle des 2 cellules a tort (2 cellules = pas de vote possible,
    // contrairement à un système 3 cellules) — Cell 1/Cell 2 restent
    // affichées normalement, c'est au plongeur de trancher (ex: 2e Drem).
    // Position cx/cy = première estimation, à valider sur photo réelle
    // comme tout le reste (jamais de coordonnée figée sans preuve).
    if (divergence) {
        // v5.5.3 — cadence propre, plus "frénétique" que l'AL_DEAD calme
        // (qui représente une situation figée/terminale) : la divergence
        // est un avertissement actif, elle doit attirer l'œil plus vite.
        uint32_t tb = millis() % DIVERGENCE_BLINK_MS;
        if (tb < DIVERGENCE_BLINK_ON) {
            fbDrawSpriteTintedScaled((E4_VL+E4_VR)/2, 58,
                SPRITE_DEAD, SPRITE_DEAD_ALPHA, SPRITE_DEAD_W, SPRITE_DEAD_H, 0, 4);
        }
    } else {
        bool votOk = c1CalOk() || c2CalOk();   // v5.11.0 — une seule cellule suffit
        fmtPPO2(buf, sizeof(buf), voting, votOk);
        fbTextCenterTop(E4_VL, E4_VR, 40, buf,
                        votOk ? colV : COL_RED, &FreeSerifBoldItalic24pt7b);
    }

    // ── PPO2 C1 — géant gauche, baseline y=180 ──────────────────────
    // "ERR" rouge si cellule hors plage mV (v4.2 : texte, plus de sprite)
    if (!g_c1.ok) {
        fbDrawTextColCenteredFS(20, 140, 146, "ERR", COL_RED, &FreeSansBold24pt7b);
    } else {
        fmtPPO2(buf, sizeof(buf), c1_ppo2, c1CalOk());
        fbTextHugeLeft(E4_C1L, 180, buf,
                       c1CalOk() ? dimColor(col1, alpha1) : COL_RED, &FreeSansBold24pt7b);
    }

    // ── PPO2 C2 — géant droite, baseline y=180 ──────────────────────
    if (!g_c2.ok) {
        fbDrawTextColCenteredFS(315, 435, 146, "ERR", COL_RED, &FreeSansBold24pt7b);
    } else {
        fmtPPO2(buf, sizeof(buf), c2_ppo2, c2CalOk());
        fbTextHugeRight(E4_C2R, 180, buf,
                        c2CalOk() ? dimColor(col2, alpha2) : COL_RED, &FreeSansBold24pt7b);
    }

    // ── mV C1/C2 — FreeSansBold18pt, baseline y=175 ─────────────────
    snprintf(buf, sizeof(buf), "%.1f mv", c1_mv);
    fbTextLeft( E4_C1L, 175, buf, COL_BLUE_DARK, &FreeSansBold18pt7b);
    snprintf(buf, sizeof(buf), "%.1f mv", c2_mv);
    fbTextRight(E4_C2R, 175, buf, COL_BLUE_DARK, &FreeSansBold18pt7b);

    // ── Batterie : logo (% remplissage) + volts (tension) ───────────
    // v4.6.6 : COL_DARK_* (v4.6.5) étaient trop sombres, plus assez visibles
    // — couleurs dédiées à ton intermédiaire à la place (voir défs plus haut).
    uint16_t bat_col = bat_pct>=50 ? COL_BATT_GREEN : bat_pct>=25 ? COL_BATT_ORANGE : COL_BATT_RED;
    drawBatteryAAA((E4_VL+E4_VR)/2, 195, 30, 60, bat_pct, bat_col);  // logo top=195
    snprintf(buf, sizeof(buf), "%.2f V", bat_v);
    fbTextCenterTop(E4_VL, E4_VR, 260, buf, bat_col, &FreeSansBold12pt7b);  // volts y_top=260

    // ── Indicateurs radios OTA/BTH (v4.2.5, spec Fred) ────────────────
    // Gris moyen (discret) = radio permise mais pas connectée
    // Vert foncé = opérationnelle | Rouge foncé = verrou tension batterie
    uint16_t ota_col = !g_radios_on ? COL_DARK_RED :
                       (WiFi.status() == WL_CONNECTED ? COL_DARK_GREEN : COL_MID_GREY);
    uint16_t bth_col = !g_radios_on ? COL_DARK_RED :
                       (g_ble_up ? COL_DARK_GREEN : COL_MID_GREY);
    fbDrawTextTop(E4_C1L + 18, 260, "OTA", ota_col, &FreeSansBold12pt7b);
    fbDrawTextTop(E4_C2R - 18 - textWidthFS("BTH", &FreeSansBold12pt7b), 260,
                  "BTH", bth_col, &FreeSansBold12pt7b);
}

// ═══════════════════════════════════════════════════════════════════════
//  AL_DEAD — écran d'urgence (2 cellules KO simultanément)
//  Fond noir + crâne/tibias croisés (sprite_dead, couleurs déjà "cuites")
//  Texte "YOU ARE DEAD !" clignotant — crâne fixe
//  HUD LEDs toutes éteintes — boucle infinie, AUCUN retour
//  Sortie : coupure manuelle du reed NF (aimant) — pas de gestion logicielle
// ═══════════════════════════════════════════════════════════════════════
#define AL_DEAD_CX     (LAND_W/2)   // centre horizontal du sprite (crâne+tibias)
#define AL_DEAD_CY     114          // centre vertical du sprite 220×220 (haut=4, bas=224)
// ATTENTION : fbDrawTextFreeSans()/fbDrawTextCenteredFS() positionnent le HAUT
// du canvas texte (60px) à y_param — le baseline visuel réel tombe à y_param+54,
// PAS à y_param (c'est ce qui coupait le texte en bas précédemment).
#define AL_DEAD_TXT_Y  214          // → baseline visuel réel ≈ 268, texte remonté et non coupé
// (AL_DEAD_BLINK_MS/ON déplacés avant drawE4Frame — v5.5.1, cf. plus haut)

// v5.1.0 — échappatoire MANUELLE : maintenir l'aimant sur le reed NO
// (même CAL_REED_HOLD_MS que la calibration normale) relance une vraie
// calibration in-situ avec le g_fio2_ref courant (donc une valeur fraîchement
// écrite en BLE pour rattraper une mauvaise manip banc — plus besoin de
// rincer/rebooter juste pour ça). Volontairement NON automatique : en vraie
// plongée, si les 2 cellules sont réellement mortes, l'écran ne doit jamais
// se croire guéri tout seul. showScreenCA1CA2() retourne toujours (jamais
// bloquante) — on ressort de AL_DEAD seulement si elle a validé au moins
// une cellule.
void showScreenALDEAD() {
    // Toutes les HUD LEDs éteintes tant qu'on n'a pas récupéré une cellule valide
    ledcWrite(PIN_LED_RED,    0);
    ledcWrite(PIN_LED_GREEN,  0);
    ledcWrite(PIN_LED_ORANGE, 0);

    static uint32_t reed_since   = 0;   // statics dédiés à AL_DEAD — indépendants
    static bool     reed_rearmed = true; // de ceux de loop() (portée différente)

    while (true) {
        if (g_radios_on) ArduinoOTA.handle();   // OTA vivant même en écran d'urgence

        // Reed NO maintenu 1s → tentative de recalibration en direct
        if (digitalRead(PIN_REED_CALIB) == LOW) {
            if (reed_rearmed) {
                if (reed_since == 0) reed_since = millis();
                if (millis() - reed_since >= CAL_REED_HOLD_MS) {
                    reed_since   = 0;
                    reed_rearmed = false;   // exige un retrait d'aimant avant de rejouer
                    showScreenCA1CA2();     // vraie mesure + calibSave() si valide
                    if (!g_c1.ok && !g_c2.ok) {
                        // toujours KO — on reste dans l'écran de la mort
                        ledcWrite(PIN_LED_RED, 0); ledcWrite(PIN_LED_GREEN, 0); ledcWrite(PIN_LED_ORANGE, 0);
                    } else {
                        Serial.println("AL_DEAD -> recalibration reussie, retour E4");
                        return;   // au moins 1 cellule valide : on ressort proprement
                    }
                }
            }
        } else {
            reed_since   = 0;
            reed_rearmed = true;
        }

        // v5.14.3 — FIX : le bouton CALIBRER (BLE, lot 4) ne déclenchait
        // showScreenCA1CA2() QUE depuis loop() (E4 normal). Or loop() ne
        // tourne PAS pendant AL_DEAD (while(true) séparé ci-dessus) — donc
        // le bouton était sourd exactement dans le cas où Fred en a le plus
        // besoin (aimant perdu + 2 cellules mortes). NimBLE traite les
        // écritures dans sa propre tâche, donc g_ble_calib_trigger peut
        // très bien passer à true ICI ; sans ce bloc il restait bloqué à
        // true en silence et aurait déclenché une calib parasite au retour
        // en E4. Même logique que le bloc reed juste au-dessus.
        if (g_ble_calib_trigger) {
            g_ble_calib_trigger = false;
            g_ble_calib_armed   = false;
            showScreenCA1CA2();
            if (!g_c1.ok && !g_c2.ok) {
                ledcWrite(PIN_LED_RED, 0); ledcWrite(PIN_LED_GREEN, 0); ledcWrite(PIN_LED_ORANGE, 0);
            } else {
                Serial.println("AL_DEAD -> recalibration BLE reussie, retour E4");
                return;
            }
        }

        fbFill(COL_BLACK);

        // Crâne + tibias croisés — tint=0 → couleurs d'origine du sprite (blanc/rouge)
        fbDrawSpriteTinted(AL_DEAD_CX, AL_DEAD_CY,
            SPRITE_DEAD, SPRITE_DEAD_ALPHA, SPRITE_DEAD_W, SPRITE_DEAD_H, 0);

        // Texte clignotant — crâne fixe, seul le texte clignote
        uint32_t tb = millis() % AL_DEAD_BLINK_MS;
        if (tb < AL_DEAD_BLINK_ON) {
            fbDrawTextCenteredFS(AL_DEAD_TXT_Y, "YOU ARE DEAD !", COL_RED, &FreeSansBold24pt7b);
        }

        flushToDisplay();
        delay(41);   // ~24 FPS, cohérent avec le reste du firmware
    }
    // ── Sortie normale : recalibration réussie (ci-dessus) ──
    // ── Sortie de secours : coupure manuelle du reed NF (aimant) ──
}

// ═══════════════════════════════════════════════════════════════════════
//  CALIBRATION — CA1 (stabilisation) + CA2 (résultat)
//  Déclenché par reed NO (PIN_REED_CALIB) depuis E4 — voir loop()
//  Même mise en page que E4 (colonnes E4_C1L/VL/C2L, mêmes ancrages sprite)
//  v4.0.0 : vraies lectures ADS1115 live + moyenne finale + sauvegarde NVS
// ═══════════════════════════════════════════════════════════════════════
#define CA_BAR_X   20
#define CA_BAR_Y   250
#define CA_BAR_W   (LAND_W - 2*CA_BAR_X)
#define CA_BAR_H   16

void showScreenCA1CA2() {
    hudAllOff();   // HUD éteint pendant la calibration (transitions air→O2
                   // sans signification plongée — E4 reprend la main au retour)
    char buf[24], buf2[24];

    // v4.2 : plus de fondu d'entrée — CA1 compose ses frames directement

    uint32_t tstart = millis();

    // Accumulateurs pour la moyenne des CA_AVG_MS dernières ms de stabilisation
    float    ca_sum1 = 0.0f, ca_sum2 = 0.0f;
    uint32_t ca_navg = 0;

    // ── CA1 : stabilisation ──────────────────────────────────────────
    while (millis() - tstart < CA1_DURATION_MS) {
        float t        = (float)(millis() - tstart) / 1000.0f;
        float progress = (float)(millis() - tstart) / (float)CA1_DURATION_MS;

        // Vraies lectures live — même machine d'état capteurs que E4
        sensorsUpdate();
        float c1mv = g_c1.mv;
        float c2mv = g_c2.mv;

        // Fenêtre de moyenne : les CA_AVG_MS dernières ms avant le verdict
        if (millis() - tstart >= CA1_DURATION_MS - CA_AVG_MS) {
            ca_sum1 += c1mv; ca_sum2 += c2mv; ca_navg++;
        }

        fbFill(COL_BLACK);

        fbTextLeft( E4_C1L, 18, "Cell 1", COL_BLUE_DARK, &FreeSansBold18pt7b);
        fbTextRight(E4_C2R, 18, "Cell 2", COL_BLUE_DARK, &FreeSansBold18pt7b);

        // mV "live" — taille normale (plus lisible qu'en géant, ne chevauche plus le centre)
        snprintf(buf, sizeof(buf), "%.1f mv", c1mv);
        fbTextLeft ( E4_C1L, 82, buf, COL_WHITE, &FreeSansBold24pt7b);
        snprintf(buf, sizeof(buf), "%.1f mv", c2mv);
        fbTextRight( E4_C2R, 82, buf, COL_WHITE, &FreeSansBold24pt7b);

        // Aperçu PPO2 (seulement si une calib précédente existe déjà)
        // v5.11.0 — l'aperçu s'appuie sur la calibration PRÉCÉDENTE : il n'a
        // de sens que si ses références correspondent encore. Sinon, tirets.
        if (g_calib_c1 > 0.0f) {
            if (c1CalOk()) snprintf(buf, sizeof(buf), "-> %.2f bar", (c1mv/g_calib_c1)*g_fio2_ref*mbarFactor());
            else           snprintf(buf, sizeof(buf), "-> --- bar");
            fbTextLeft(E4_C1L, 128, buf, COL_BLUE_DARK, &FreeSansBold18pt7b);
        }
        if (g_calib_c2 > 0.0f) {
            if (c2CalOk()) snprintf(buf, sizeof(buf), "-> %.2f bar", (c2mv/g_calib_c2)*g_fio2_ref*mbarFactor());
            else           snprintf(buf, sizeof(buf), "-> --- bar");
            fbTextRight(E4_C2R, 128, buf, COL_BLUE_DARK, &FreeSansBold18pt7b);
        }

        // "STABILIZING..." qui pulse doucement — même police que le label "Voting" en E4
        uint8_t pulse = flashCurve(fmodf(t/1.2f, 1.0f));
        fbTextCenterTop(E4_VL, E4_VR, 12, "STABILIZ...",
            dimColor(COL_GREEN, 80+(pulse*175/255)), &FreeSerifBoldItalic12pt7b);

        // v5.10.0 — référence de pression pendant la STABILISATION. Écran
        // oublié jusqu'ici, et pourtant le plus important des quatre : 10s
        // pendant lesquelles Fred fixe l'appareil pendant qu'il établit la
        // sensibilité mV/bar des cellules. Si la référence est fausse, c'est
        // MAINTENANT qu'il faut le voir, pas sur l'écran de résultat.
        // Colonne centrale libre de ~35 à ~205 ("STABILIZ..." 12-29 en haut,
        // titre à 212 en bas) : icône 70-94, valeur 104-121.
        drawPressureRef((E4_VL+E4_VR)/2, 70, E4_VL, E4_VR, 104);

        // Titre calibration — déplacé entre le centre et la barre de progression
        // (le %O2 vient de g_fio2_ref, modifiable via BT — reste dynamique ici)
        snprintf(buf, sizeof(buf), "Calibration - %d%% O2", (int)(g_fio2_ref*100.0f+0.5f));
        fbTextCenterTop(0, LAND_W, 212, buf, COL_WHITE, &FreeSerifBoldItalic18pt7b);

        // Barre de progression pleine largeur, bas d'écran
        fbRect(CA_BAR_X, CA_BAR_Y, CA_BAR_W, CA_BAR_H, COL_DARK_GREY);
        fbRect(CA_BAR_X, CA_BAR_Y, (int)(CA_BAR_W*progress), CA_BAR_H, COL_GREEN);
        fbRect(CA_BAR_X, CA_BAR_Y, CA_BAR_W, 2, COL_WHITE);
        fbRect(CA_BAR_X, CA_BAR_Y+CA_BAR_H-2, CA_BAR_W, 2, COL_WHITE);

        flushToDisplay();
        if (g_radios_on) ArduinoOTA.handle();
        delay(41);
    }

    // ── Valeur retenue = moyenne des CA_AVG_MS dernières ms, validée ──
    // Plage rEvodream 36-64mV@O2pur mise à l'échelle du FiO2 de référence
    // (à 0.21 air : 7.7-13.7mV → calibration air complète possible au banc)
    // v5.7.0 — ET de la pression. Sans ce facteur, une cellule saine est
    // refusée à tort en altitude : la cellule produit réellement moins de mV
    // quand la pression baisse, alors que la fenêtre resterait calée sur
    // 1013. C'est exactement le piège du mode SeaLvl du Shearwater, qui ne
    // met PAS sa fenêtre 30-70mV à l'échelle quand on lui fige la pression
    // (déjà vécu par Fred : refus de calibration cellule fatiguée + BP).
    // En config A le facteur vaut 1.0 → plage identique à v5.6.0.
    float cal_min = CAL_MV_MIN_O2 * (g_fio2_ref / FIO2_O2_PUR) * mbarFactor();
    float cal_max = CAL_MV_MAX_O2 * (g_fio2_ref / FIO2_O2_PUR) * mbarFactor();
    float final_c1mv = ca_navg ? ca_sum1 / (float)ca_navg : g_c1.mv;
    float final_c2mv = ca_navg ? ca_sum2 / (float)ca_navg : g_c2.mv;
    bool  c1_valid = (final_c1mv >= cal_min && final_c1mv <= cal_max);
    bool  c2_valid = (final_c2mv >= cal_min && final_c2mv <= cal_max);

    // N'écrase PAS une calib précédente valide si la nouvelle lecture est hors plage
    // Une calibration réussie réhabilite aussi le latch de confiance (check air E3)
    if (c1_valid) g_calib_c1 = final_c1mv;
    if (c2_valid) g_calib_c2 = final_c2mv;
    // v5.9.0 — verdict PAR cellule, persisté. Une cellule qui vient d'échouer
    // est marquée KO ; une qui vient de réussir est blanchie. Note : quand
    // une seule échoue, l'autre reste pleinement utilisable — c'est tout
    // l'intérêt du mode dégradé, encore faut-il DÉSIGNER la fautive.
    g_c1_cal_ko = !c1_valid;
    g_c2_cal_ko = !c2_valid;
    // Sauvegarde INCONDITIONNELLE depuis la v5.9.0. Avant, elle était sous
    // "if (c1_valid || c2_valid)" : un double échec n'écrivait donc RIEN et
    // les drapeaux KO se seraient perdus au reboot — exactement le cas que
    // Fred veut voir survivre.
    calibSave();   // persistance NVS — survit à la coupure du reed NF
    Serial.printf("Calib NVS sauvee: C1=%.1fmV(%s) C2=%.1fmV(%s)\n",
                  final_c1mv, c1_valid?"OK":"KO", final_c2mv, c2_valid?"OK":"KO");

    // ── CA2 : résultat (v4.2.2 — layout dédoublonné, zéro chevauchement) ─
    // Bandes verticales : titres 18→~45 / verdicts ~77→110 / message 150→~185
    // / mV ~192→225. Le verdict global redondant (OK central) est supprimé :
    // les deux verdicts par cellule + le message coloré disent tout.
    fbFill(COL_BLACK);

    fbTextLeft( E4_C1L, 18, "Cell 1", COL_BLUE_DARK, &FreeSansBold18pt7b);
    fbTextRight(E4_C2R, 18, "Cell 2", COL_BLUE_DARK, &FreeSansBold18pt7b);

    // Verdict OK/ERR par cellule — sous les titres, bande dégagée
    int c1_cx = (E4_C1L+E4_C1R)/2, c2_cx = (E4_C2L+E4_C2R)/2;
    fbDrawTextColCenteredFS(c1_cx-60, c1_cx+60, 90, c1_valid ? "OK" : "ERR",
        c1_valid ? COL_GREEN : COL_RED, &FreeSansBold24pt7b);
    fbDrawTextColCenteredFS(c2_cx-60, c2_cx+60, 90, c2_valid ? "OK" : "ERR",
        c2_valid ? COL_GREEN : COL_RED, &FreeSansBold24pt7b);

    // mV final — remontés sous les verdicts (v4.2.4, layout façon Shearwater)
    snprintf(buf,  sizeof(buf),  "%.1f mv", final_c1mv);
    snprintf(buf2, sizeof(buf2), "%.1f mv", final_c2mv);
    fbTextLeft( E4_C1L, 138, buf,  COL_WHITE, &FreeSansBold18pt7b);
    fbTextRight(E4_C2R, 138, buf2, COL_WHITE, &FreeSansBold18pt7b);

    // Message tri-état — TOUT EN BAS, comme la ligne de statut du Shearwater
    bool all_ok = c1_valid && c2_valid;
    bool any_ok = c1_valid || c2_valid;
    fbTextCenterTop(0, LAND_W, 215,
        all_ok ? "Calibration terminee" :
        any_ok ? "Calibration partielle !" : "ERREUR calibration",
        all_ok ? COL_GREEN : any_ok ? COL_ORANGE : COL_RED,
        &FreeSerifBoldItalic18pt7b);

    // v5.7.0 — pression de calibration au centre (zone libre : les verdicts
    // et mV sont dans les colonnes latérales, le centre était vide).
    // C'est LE paramètre de cette calibration : il doit être tracé avec elle.
    drawPressureRef((E4_VL+E4_VR)/2, 88, E4_VL, E4_VR, 118);

    flushToDisplay();
    uint32_t hold = millis();
    // v5.8.0 — 10s au lieu de 2s si au moins une cellule a échoué : le temps
    // de lire, comprendre et photographier. Le succès garde ses 2s (rien à
    // analyser, et Fred enchaîne sur sa vérification 0.98/0.98 au Shearwater).
    uint32_t hold_ms = (c1_valid && c2_valid) ? CA2_HOLD_MS : CA2_HOLD_ERR_MS;
    while (millis()-hold < hold_ms) { if (g_radios_on) ArduinoOTA.handle(); delay(41); }

    // ── Retour E4 — coupe sèche (v4.2) ────────────────────────────────
    // Recalcule les PPO2 avec la calibration fraîchement validée
    cellCompute(g_c1, g_calib_c1);
    cellCompute(g_c2, g_calib_c2);

    // Même formule voting que loop() (v5.0.0) — évite de moyenner avec une
    // cellule dont la calib vient d'échouer (ppo2=0) le temps d'une frame
    float vote = (g_c1.ok && g_c2.ok) ? (g_c1.ppo2 + g_c2.ppo2) / 2.0f
               : (g_c1.ok ? g_c1.ppo2 : g_c2.ppo2);
    drawE4Frame(g_c1.ppo2, g_c1.mv, g_c2.ppo2, g_c2.mv, vote, g_bat_v, g_bat_pct, 0.0f, false);
    flushToDisplay();
}

// ═══════════════════════════════════════════════════════════════════════
//  TRANSITION E3 → E4 — fondu propre depuis le noir de fin E3
//  crossbuf et textbuf contiennent du noir après showSplash3()
// ═══════════════════════════════════════════════════════════════════════
void showScreenE4() {
    // v4.2 : plus de fondu — dessin direct de la première frame E4
    // NB : à cet instant g_c1/g_c2.ppo2 valent encore 0 (E3 ne remplit que
    // mv/ok) — la vraie valeur arrive à la 1re frame de loop(), ~40ms après.
    float vote = (g_c1.ok && g_c2.ok) ? (g_c1.ppo2 + g_c2.ppo2) / 2.0f
               : (g_c1.ok ? g_c1.ppo2 : g_c2.ppo2);
    drawE4Frame(g_c1.ppo2, g_c1.mv, g_c2.ppo2, g_c2.mv, vote, g_bat_v, g_bat_pct, 0.0f, false);
    flushToDisplay();
}

// ═══════════════════════════════════════════════════════════════════════
//  BLE — code réel depuis le chat 3.1 BT, mergé v4.4.0
//  initBLE() appelé APRÈS la tentative WiFi (voir setup()) — plus avant E1
//  depuis v4.5.1 (radio RF partagée, cf. commentaire dans setup())
// ═══════════════════════════════════════════════════════════════════════
void initBLE() {
    bleInit();
    // Paramètres exposés : mode HUD, FiO2, voting, luminosité, altitude,
    //                      lecture batterie/mV, reset défauts, âges cellules
}

// ═══════════════════════════════════════════════════════════════════════
//  OTA — mise à jour firmware par WiFi !! NE PAS MODIFIER !!
// ═══════════════════════════════════════════════════════════════════════
void setupOTA() {
    ArduinoOTA.setHostname(OTA_HOSTNAME);
    ArduinoOTA.setPassword(OTA_PASSWORD);
    ArduinoOTA.setPort(3232);
    ArduinoOTA.onStart([]() {
        Serial.println("OTA start");
        fbFill(COL_BLACK); fbRect(28, 100, 400, 30, 0x2104); flushToDisplay();
    });
    ArduinoOTA.onProgress([](unsigned int p, unsigned int t) {
        fbRect(28, 100, p/(t/100)*4, 30, COL_GREEN); flushToDisplay();
    });
    ArduinoOTA.onEnd([]()          { fbFill(COL_GREEN); flushToDisplay(); });
    ArduinoOTA.onError([](ota_error_t e) {
        Serial.printf("OTA err %u\n", e); fbFill(COL_RED); flushToDisplay();
    });
    ArduinoOTA.begin();
    Serial.printf("OTA pret: %s:3232\n", OTA_HOSTNAME);
}

// ═══════════════════════════════════════════════════════════════════════
//  SETUP
// ═══════════════════════════════════════════════════════════════════════
void setup() {
    Serial.begin(115200); delay(500);
    Serial.println("\n=== GfredDream v5.14.3 ===");

    // Configuration des GPIOs
    ledcAttach(PIN_LED_RED,    5000, 8);   // PWM 5kHz/8-bit — luminosité HUD réglable (v4.5.0)
    ledcAttach(PIN_LED_GREEN,  5000, 8);
    ledcAttach(PIN_LED_ORANGE, 5000, 8);
    pinMode(PIN_REED_CALIB, INPUT_PULLUP);
    Wire.begin(PIN_I2C_SDA, PIN_I2C_SCL);

    // Détection ADS1115 + chargement calibration persistée (NVS)
    g_ads_ok = adsPresent();
    Serial.println(g_ads_ok ? "ADS1115 OK @0x48" : "ADS1115 ABSENT ! (cellules KO -> AL_DEAD)");
    calibLoad();
    bleParamsLoad();
    Serial.printf("Calib NVS: C1=%.1fmV C2=%.1fmV FiO2=%.2f\n",
                  g_calib_c1, g_calib_c2, g_fio2_ref);

    // Allocation des 4 buffers PSRAM (~1MB sur 8MB dispo)
    framebuf     = (uint16_t*)ps_malloc((size_t)LAND_W * LAND_H * 2);
    portrait_buf = (uint16_t*)ps_malloc((size_t)PHYS_W * PHYS_H * 2);
    textbuf      = (uint16_t*)ps_malloc((size_t)LAND_W * LAND_H * 2);
    crossbuf     = (uint16_t*)ps_malloc((size_t)LAND_W * LAND_H * 2);
    if (!framebuf || !portrait_buf || !textbuf || !crossbuf) {
        Serial.println("ERREUR PSRAM !"); return;
    }
    Serial.println("PSRAM OK");

    // Canvas texte normal 456×60px
    canvas = new Arduino_Canvas(LAND_W, 60, nullptr);
    if (!canvas->begin(GFX_SKIP_OUTPUT_BEGIN)) {
        Serial.println("canvas FAIL"); delete canvas; canvas = nullptr;
    } else Serial.println("canvas OK");

    // Canvas PPO2 géant 456×120px (setTextSize 2 → ~48pt réel)
    canvasLarge = new Arduino_Canvas(LAND_W, 120, nullptr);
    if (!canvasLarge->begin(GFX_SKIP_OUTPUT_BEGIN)) {
        Serial.println("canvasLarge FAIL"); delete canvasLarge; canvasLarge = nullptr;
    } else Serial.println("canvasLarge OK");

    // Display
    if (!display->begin()) { Serial.println("ERREUR display !"); return; }
    Serial.println("Display OK");
    // Luminosité écran — reliée au vrai hardware (v4.6.4). g_brightness (0-100,
    // déjà chargé par bleParamsLoad() ci-dessus) → 0-255 pour setBrightness().
    // API confirmée : Arduino_CO5300::setBrightness(uint8_t), commande CO5300
    // CO5300_W_WDBRIGHTNESSVALNOR — trouvée dans le code source réel de la lib
    // (moononournation/Arduino_GFX), pas une supposition.
    display->setBrightness((uint8_t)((uint16_t)g_brightness * 255 / 100));

    // Verrou radio batterie faible (v4.2) : lecture tension AVANT tout
    // lancement radio. L'épisode "OTA sur batterie faible → brownout →
    // décharge profonde → recâblage" ne doit plus JAMAIS se reproduire.
    float boot_batv_early = readBatteryVolts();
    if (boot_batv_early >= BAT_V_RADIO_MIN) {
        // WiFi lancé en NON-BLOQUANT avant les splashs — se connecte en
        // arrière-plan pendant E1/E2/E3 (~10s). Le BLE, lui, attend que la
        // tentative WiFi soit COMPLÈTEMENT terminée (voir plus bas, après
        // la vérification WiFi.status()) — v4.4.0 le lançait ici, juste
        // après WiFi.begin(), et le BLE restait invisible en scan : la
        // radio ESP32-S3 est partagée, WiFi doit avoir fini sa poignée de
        // main AVANT que NimBLE y touche, pas seulement l'avoir commencée.
        WiFi.mode(WIFI_STA);
        WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
        Serial.printf("WiFi: connexion (%s)...\n", WIFI_SSID);
        g_radios_on = true;
    } else {
        Serial.printf("Batterie %.2fV < %.2fV -> WiFi/OTA/BLE DESACTIVES (recharger !)\n",
                      boot_batv_early, BAT_V_RADIO_MIN);
    }

    // Séquence de boot (E1 → E2 → E3)
    showSplashBoot();   // E1 ~3.7s — logo animé sur fond plongeur
    showSplash12();     // E2 ~2.7s — titre et version
    // E3 — vraies lectures : cellules (bloquant ~10ms/cellule) + batterie
    float boot_c1mv = adsReadCellMvBlocking(0);
    float boot_c2mv = adsReadCellMvBlocking(1);
    float boot_batv = readBatteryVolts();
    Serial.printf("Boot: C1=%.1fmV C2=%.1fmV Bat=%.2fV\n",
                  boot_c1mv, boot_c2mv, boot_batv);
    showSplash3(boot_c1mv, boot_c2mv, boot_batv);  // E3 ~4s

    // v5.13.0 — plus de latch de confiance : E3 est purement informatif,
    // il ne verrouille plus rien pour E4.
    // Fallback "calibration air" au premier boot (aucune calib NVS) :
    // à l'air en surface PPO2 = 0.209 bar → calib équivalente = mv_air × FiO2ref/0.209
    // Permet à E4 d'afficher une PPO2 plausible avant la première vraie calibration.
    if (g_calib_c1 < 1.0f && boot_c1mv > CELL_MV_LIVE_MIN) {
        g_calib_c1 = boot_c1mv * (g_fio2_ref / 0.209f);
        Serial.printf("Calib air fallback C1: %.1fmV\n", g_calib_c1);
    }
    if (g_calib_c2 < 1.0f && boot_c2mv > CELL_MV_LIVE_MIN) {
        g_calib_c2 = boot_c2mv * (g_fio2_ref / 0.209f);
        Serial.printf("Calib air fallback C2: %.1fmV\n", g_calib_c2);
    }

    // PPO2 initiales pour le pré-rendu E4
    cellCompute(g_c1, g_calib_c1);
    cellCompute(g_c2, g_calib_c2);

    // Vérification WiFi après les splashs (résultat quasi-instantané)
    if (g_radios_on && WiFi.status() == WL_CONNECTED) {
        Serial.printf("WiFi OK — %s\n", WiFi.localIP().toString().c_str());
        MDNS.begin(OTA_HOSTNAME);
        setupOTA();
    } else if (g_radios_on) {
        Serial.println("WiFi FAIL — OTA indisponible");
    }

    // BLE — lancé APRÈS que la tentative WiFi soit terminée (connectée ou
    // non), jamais pendant : radio RF partagée ESP32-S3 (cf. commentaire
    // ci-dessus). Ordre validé sur le vrai matériel via GfredDream_BLE_test.
    if (g_radios_on) initBLE();

    // Transition E3 → E4 avec fondu propre
    showScreenE4();

    Serial.println("=== Boot OK ===");
    hudAllOff();   // le HUD prend sa vraie sémantique PPO2 dès la 1re frame E4
}

// ═══════════════════════════════════════════════════════════════════════
//  LOOP — E4 principal @ 24 FPS + gestion OTA
// ═══════════════════════════════════════════════════════════════════════
// v5.5.0 — seuil de divergence C1/C2 (~0.2 bar/20% façon Shearwater, mais
// système 2 cellules → on alerte, on ne tranche jamais à la place de Fred).
#define DIVERGENCE_THRESHOLD_BAR 0.15f
#define DIVERGENCE_DEBOUNCE_MS   1500    // 1.5s avant de basculer, dans un sens ou l'autre

void loop() {
    if (g_radios_on) ArduinoOTA.handle();   // vérification OTA à chaque frame

    static uint32_t last_frame = 0;
    static uint32_t last_log   = 0;

    if (millis() - last_frame < 41) return;   // 41ms = ~24 FPS
    last_frame = millis();

    // Rafraîchit les capteurs — machine d'état non-bloquante :
    // ADS1115 alterné C1/C2 (~12Hz/cellule) + batterie GPIO1 toutes les 500ms
    sensorsUpdate();

    float c1   = g_c1.ppo2;    // PPO2 Cellule 1 (mv / calib × FiO2)
    float c1mv = g_c1.mv;      // mV lissés Cellule 1 (diff A0/A1)
    float c2   = g_c2.ppo2;    // PPO2 Cellule 2
    float c2mv = g_c2.mv;      // mV lissés Cellule 2 (diff A2/A3)
    float batv = g_bat_v;      // tension LiPo (GPIO1 × pont diviseur)
    int   batp = g_bat_pct;


    // v5.13.0 — flash de transition si l'état OK/ERR d'une cellule a changé
    // depuis la frame précédente (idée Fred). En plongée, une cellule qui
    // lâche ou qui revient est un ÉVÉNEMENT, distinct de l'état permanent
    // (marqueur ERR sur la colonne). Non déclenché au tout premier passage
    // (init des statics), ni pendant AL_DEAD (les 2 KO = écran dédié).
    static bool s_prev_init = false;
    static bool s_prev_c1ok = true, s_prev_c2ok = true;
    if (s_prev_init && (g_c1.ok != s_prev_c1ok || g_c2.ok != s_prev_c2ok)
                    && (g_c1.ok || g_c2.ok)) {
        hudTransitionFlash();
    }
    s_prev_c1ok = g_c1.ok; s_prev_c2ok = g_c2.ok; s_prev_init = true;

    // AL_DEAD — 2 cellules KO simultanément → écran d'urgence, ne retourne jamais
    if (!g_c1.ok && !g_c2.ok) showScreenALDEAD();

    // v5.5.0 — DIVERGENCE C1/C2 : les 2 cellules sont vivantes (sinon on
    // serait dans AL_DEAD ou en mode 1-cellule ci-dessous) mais ne sont
    // pas d'accord entre elles. Avec seulement 2 cellules, impossible de
    // savoir laquelle a tort (pas de vote majoritaire comme sur un
    // système à 3 cellules) — donc on n'invente aucune valeur : Cell 1 et
    // Cell 2 restent affichées telles quelles, c'est au plongeur de
    // trancher (typiquement via le 2e Drem monté à côté).
    // Hystérésis DIVERGENCE_DEBOUNCE_MS pour éviter un battement si
    // l'écart oscille pile autour du seuil.
    static bool     g_divergence      = false;
    static uint32_t g_divergence_since = 0;
    bool raw_diverging = g_c1.ok && g_c2.ok
                       && (fabsf(c1 - c2) > DIVERGENCE_THRESHOLD_BAR);
    if (raw_diverging != g_divergence) {
        if (g_divergence_since == 0) g_divergence_since = millis();
        if (millis() - g_divergence_since >= DIVERGENCE_DEBOUNCE_MS) {
            g_divergence = raw_diverging;
            g_divergence_since = 0;
        }
    } else {
        g_divergence_since = 0;
    }

    // Valeur voting centrale — ALIGNÉE sur le HUD depuis v5.0.0 :
    // les 2 cellules OK → moyenne ; 1 seule OK → la valide SEULE.
    // (Avant v5.0.0 l'écran alternait C1/C2 toutes les 3s — cohérent quand
    // le label alternait aussi "Cell 1"/"Cell 2", mais depuis v4.5.0 le
    // label est fixé à "Voting" : afficher la valeur d'une cellule KO sous
    // ce label induisait en erreur. Le gros "ERR" sur sa colonne suffit.)
    float vote = (g_c1.ok && g_c2.ok) ? (c1+c2)/2.0f
               : (g_c1.ok ? c1 : c2);

    // HUD physique : même logique — une cellule KO ne pilote jamais les
    // LEDs ; une divergence non plus (v5.5.0) — mieux vaut un HUD éteint
    // et sans ambiguïté qu'un HUD qui pulse sur une moyenne trompeuse.
    //
    // v5.11.0 — MÊME RÈGLE quand la calibration n'est pas exploitable
    // (décision Fred, 24/07 : "un truc qui va pas, HUD éteint, c'est tout").
    // C'était le dernier mensonge qui restait : PPO2 interne à 0.00 → le HUD
    // clignotait orange rapide, donc annonçait une HYPOXIE, alors que la
    // vraie information est "je ne sais pas". Un plongeur qui réagit à une
    // hypoxie inexistante peut faire une injection O2 inutile — l'erreur va
    // dans le mauvais sens. L'écran affiche déjà "---" ; le HUD doit dire la
    // même chose, et son "éteint" veut déjà dire "regarde l'écran".
    bool calUnusable = !c1CalOk() && !c2CalOk();
    if (g_divergence || calUnusable) {
        hudAllOff();
    } else {
        float hud_vote = vote;
        hudUpdate(hud_vote);
    }

    // Phase du stroboscope C1/C2 (300ms si danger, 2000ms sinon)
    uint32_t pf = min(ppo2NeedsFlash(c1)?300u:2000u, ppo2NeedsFlash(c2)?300u:2000u);
    float flash_t = (float)(millis()%pf) / (float)pf;

    // Rendu et envoi de la frame
    drawE4Frame(c1, c1mv, c2, c2mv, vote, batv, batp, flash_t, g_divergence);
    flushToDisplay();


    // Reed IO2 (NO, INPUT_PULLUP → LOW = aimant présent) → calibration CA1/CA2
    // Ce bloc ne vit QUE dans loop() = uniquement accessible depuis E4.
    // Sécurités : l'aimant doit être maintenu CAL_REED_HOLD_MS en continu,
    // et doit être RETIRÉ après une calibration avant d'en relancer une
    // (pas de re-déclenchement si l'aimant traîne sur le boîtier).
    static uint32_t reed_since   = 0;
    static bool     reed_rearmed = true;
    if (digitalRead(PIN_REED_CALIB) == LOW) {
        if (reed_rearmed) {
            if (reed_since == 0) reed_since = millis();
            if (millis() - reed_since >= CAL_REED_HOLD_MS) {
                reed_since   = 0;
                reed_rearmed = false;   // exige un retrait d'aimant avant re-calib
                showScreenCA1CA2();
            }
        }
    } else {
        reed_since   = 0;
        reed_rearmed = true;
    }

    // Lot 4 — CALIBRER distant (BLE 1234000D, séquence ARM 0x5A / GO 0xA5)
    // Même point d'entrée unique que le reed — mêmes garanties (E4 only,
    // showScreenCA1CA2() bloquant identique). Fenêtre ARM→GO 10s, sinon
    // désarmé (voir CbCalTrig dans ble_service.h).
    if (g_ble_calib_trigger) {
        g_ble_calib_trigger = false;
        g_ble_calib_armed   = false;
        showScreenCA1CA2();
    }

    // BLE — proxies mV + notify capteurs, et sauvegarde NVS différée des
    // paramètres, toutes les ~1s (inutile de spammer plus vite qu'une appli
    // mobile ne peut lire ; no-op silencieux si BLE non actif, cf. bleUpdateSensors())
    static uint32_t last_ble = 0;
    if (millis() - last_ble > 1000) {
        last_ble = millis();
        _ble_c1_mv = c1mv;
        _ble_c2_mv = c2mv;
        bleUpdateSensors();
        if (g_params_changed) {
            display->setBrightness((uint8_t)((uint16_t)g_brightness * 255 / 100));  // v4.6.4
            bleParamsSave();
        }
    }

    // Log série toutes les 5s
    if (millis() - last_log > 5000) {
        last_log = millis();
        Serial.printf("E4 | C1=%.2f(%.1fmV) C2=%.2f(%.1fmV) Vote=%.2f Bat=%d%%\n",
                      c1, c1mv, c2, c2mv, vote, batp);
    }
}
