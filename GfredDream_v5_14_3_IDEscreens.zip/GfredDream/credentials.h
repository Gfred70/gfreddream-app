// ================================================================
// credentials.h — NE JAMAIS PARTAGER CE FICHIER !
// ================================================================
#pragma once

// ── WiFi ─────────────────────────────────────────────────────
#define WIFI_SSID      "WiFi-Gfred"
#define WIFI_PASSWORD  "MORTchaud35C"

// ── OTA (mises à jour sans fil) ──────────────────────────────
#define OTA_HOSTNAME  "GfredDream"
#define OTA_PASSWORD  "123"
