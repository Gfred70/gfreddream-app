// ═══════════════════════════════════════════════════════════════════════
//  gfred_params.h — Paramètres BLE/NVS partagés (GfredDream v5.14.3)
//  À inclure dans GfredDream.ino AVANT ble_service.h
//  Namespace NVS "gfred" — le MÊME que calibLoad()/calibSave() (cal1/cal2/
//  calfio2/fio2/mbar/calmbar) : un seul namespace pour tout le projet.
//
//  v4.5.0 : périmètre BLE volontairement réduit à ce que Fred utilise
//  vraiment (décision du 12/07/2026) — HUD mode (CCR/SMT/SCR), voting
//  alterné, et altitude sont retirés de la PWA (CCR + Voting fixes ;
//  altitude non gérée, comme le vrai rEvodream sans sonde de pression).
//  Cellules/cartouche de chaux : gérés uniquement côté appli web, aucun
//  lien avec le GfredDream (pas d'horloge/RTC à bord pour dater quoi que
//  ce soit — le tel a une horloge fiable en permanence, pas l'ESP32).
//
//  v5.7.0 : RETOUR de la pression — mais PAS sous la forme abandonnée en
//  v4.5.0. Le manuel rEvodream P/P5 officiel gère bel et bien l'altitude
//  (section "Altitude calibration") : sans sonde, il fait corriger la PPO2
//  affichée à la main. On fait mieux et plus lisible : l'utilisateur entre
//  la pression en MILLIBARS, exactement ce que le Shearwater affiche sur
//  sa ligne "Pressure mBar / NOW". Référence partagée, zéro conversion,
//  zéro approximation ISA (les mètres ne sont qu'un proxy météo-dépendant).
//
//  ═══ CONFIG A (défaut, réglage quotidien de Fred) ═══
//  SW en SeaLvl + GfredDream à 1013 → les 2 instruments s'accordent et
//  affichent 0.98 après calibration. AUCUNE action, AUCUN téléphone requis.
//  Le paramètre dort à 1013 et le firmware se comporte bit pour bit comme
//  en v5.6.0. C'est le mode de fonctionnement normal.
//
//  ═══ CONFIG B (exception : altitude réelle) ═══
//  Seuil décidé le 24/07/2026 : si le "NOW" du Shearwater < 930 mbar
//  (≈ 715 m ISA), passer en config B — SW en Auto + écriture du mbar réel
//  ici via BLE. Au-dessus de 930, l'erreur reste dans l'enveloppe PPO2
//  tolérée (0.7-1.6) : à 930 mbar, 1.30 affiché = 1.19 réel, 1.60 affiché
//  = 1.47 réel. L'erreur pousse TOUJOURS le réel sous l'affiché, donc elle
//  mange la marge hypoxique (0.60 de large) et jamais la marge hyperoxique
//  (0.30) — elle attaque la grande marge, pas la petite.
//  Sur les sites de Fred (Zélande 0 m → Liefrange ~320 m), il faudrait un
//  QNH de 930 à 966 hPa pour déclencher le seuil : la météo seule ne le
//  franchira jamais (record belge ~954 hPa). Ce seuil ne parle donc que
//  d'altitude réelle, et reste muet en Belgique / Zélande / Alsace.
// ═══════════════════════════════════════════════════════════════════════
#pragma once
#include <Arduino.h>
#include <Preferences.h>

// ── Objets/variables déjà définis dans GfredDream.ino (extern) ─────────
extern Preferences prefs;        // même objet NVS que calibLoad()/calibSave()
extern float       g_fio2_ref;   // FiO2 référence — persistance déjà gérée par calibLoad()/calibSave(),
                                  // le BLE écrit juste la clé "fio2" en plus (voir ble_service.h)
extern uint16_t    g_mbar_ref;   // Pression de calibration en mbar — même logique que g_fio2_ref :
                                  // persistance dans calibLoad()/calibSave(), clé NVS "mbar" écrite par BLE

// ── Pression de calibration (v5.7.0) ───────────────────────────────────
// Diviseur 1013 et NON 1000 : c'est la convention Shearwater (cf. leur
// support Predator, "(990/1013) x 0.98 = 0.96"). Utiliser 1000 donnerait
// des PPO2 systématiquement décalées de 1.3% par rapport au SW — or tout
// l'intérêt d'un second moniteur est de pouvoir comparer les deux chiffres.
#define MBAR_STD        1013.0f  // atmosphère standard = référence du Shearwater
#define MBAR_DEFAULT    1013     // défaut = config A = comportement v5.6.0 à l'identique
#define MBAR_MIN        700      // ≈ 3000 m — borne basse généreuse
#define MBAR_MAX        1080     // anticyclone extrême au niveau de la mer
#define MBAR_ALERT_LOW  930      // sous ce seuil → config B requise (cf. en-tête)

// ── Paramètres BLE-configurables — les 2 seuls qui restent en v4.5.0 ───
uint8_t  g_brightness      = 100;   // luminosité écran, 0-100 %
uint8_t  g_hud_brightness  = 100;   // luminosité LED du HUD, 0-100 % (PWM, séparée de l'écran)
bool     g_params_changed  = false; // mis à true par ble_service.h → déclenche bleParamsSave()

// ── Chargement au boot — appeler juste après calibLoad() dans setup() ──
inline void bleParamsLoad() {
    prefs.begin("gfred", false);
    g_brightness     = prefs.getUChar("bright", g_brightness);
    g_hud_brightness = prefs.getUChar("hudbrt", g_hud_brightness);
    prefs.end();
}

// ── Sauvegarde — appelée depuis loop() quand g_params_changed est vrai ─
inline void bleParamsSave() {
    prefs.begin("gfred", false);
    prefs.putUChar("bright", g_brightness);
    prefs.putUChar("hudbrt", g_hud_brightness);
    prefs.end();
    g_params_changed = false;
}

// ── Reset défauts usine — déclenché par écriture 0xAA sur BLE_RESET ────
// Remet FiO2 à 0.98 (demande explicite Fred, 12/07/2026) — ce N'EST PAS
// un effacement de calibration : le verrou FiO2 existant (calibLoad())
// invalidera cal1/cal2 au prochain boot si le FiO2 a changé, forçant une
// recalibration avant plongée — comportement voulu pour un reset usine.
// v5.7.0 : remet aussi la pression à 1013 (retour en config A). Même
// mécanique — le verrou pression invalidera la calib si elle avait été
// faite en config B. Un reset usine doit ramener l'appareil à son état
// "quotidien Belgique", pas le laisser sur un réglage de voyage oublié.
inline void gfredResetDefaults() {
    g_brightness     = 50;    // v5.14.3 — décision Fred : 100% était trop agressif au réveil
    g_hud_brightness = 2;     // v5.14.3 — idem, 2% = luminosité de l'original
    g_fio2_ref       = 0.98f;
    g_mbar_ref       = MBAR_DEFAULT;
    prefs.begin("gfred", false);
    prefs.putFloat("fio2",  g_fio2_ref);
    prefs.putUShort("mbar", g_mbar_ref);
    prefs.end();
    bleParamsSave();
    // v5.14.3 — FIX bug reset écran/HUD : bleParamsSave() ci-dessus remet
    // g_params_changed à false EN SORTANT DE CETTE MÊME FONCTION, avant que
    // loop() n'ait jamais eu la main. Résultat : le bloc loop() qui applique
    // display->setBrightness() (gardé par `if (g_params_changed)`, ~1×/s)
    // ne se déclenchait jamais après un reset — g_brightness changeait bien
    // en mémoire/NVS, mais l'écran physique restait sur son ancien niveau.
    // On remet le flag à true APRÈS l'appel, pour que loop() le voie au
    // prochain passage (~1s) et applique vraiment le nouveau niveau d'écran.
    g_params_changed = true;
}
