// ═══════════════════════════════════════════════════════════════════════
//  ble_service.h — Service GATT BLE GfredDream (NimBLE-Arduino v2.x, h2zero)
//  Version courante : v5.14.3 (lot 3 pression : fix télémétrie calib + CALIBRER distant)
//  À inclure dans GfredDream.ino APRÈS gfred_params.h
//
//  v4.5.0 : périmètre réduit (décision Fred 12/07/2026) — seuls FiO2 et
//  luminosité (écran + HUD séparément) restent pilotables par la PWA.
//  Mode CCR/SMT/SCR, voting alterné, altitude, cellules/chaux : retirés
//  du BLE (CCR + Voting fixes en dur ; cellules/chaux gérés uniquement
//  côté appli web, sans lien avec le device).
//
//  v5.7.0 : AJOUT de BLE_MBAR (pression de calibration, mbar). ⚠️ On NE
//  réutilise PAS 12340005 ("ALT", retiré en v4.5.0) — cf. la note sur les
//  UUID brûlés juste en dessous : un vieux dump BLE qui traînerait ferait
//  écrire une valeur d'altitude d'ancien format dans un champ pression.
//  Nouvel UUID jamais utilisé : 1234000C.
//
//  Historique : développé et débuggé dans le chat dédié "3.1 BT" — 3 bugs
//  de compilation réels y ont été corrigés (voir commentaires ci-dessous),
//  NE PAS revenir en arrière sur ces points précis.
// ═══════════════════════════════════════════════════════════════════════
#pragma once
#include <NimBLEDevice.h>
#include "gfred_params.h"

// ── Variables définies dans GfredDream.ino (extern) ─────────────────────
extern float g_bat_v;
extern int   g_bat_pct;
extern bool  g_ble_up;
extern float g_calib_c1;
extern float g_calib_c2;
// g_cal_fio2/g_cal_mbar : valeurs figées à la DERNIÈRE calibration (définies
// GfredDream.ino ligne ~516, APRÈS l'include de ce fichier — extern requis).
// On réplique ici EXACTEMENT la logique de calRefMatch()/c1CalOk()/c2CalOk()
// (mêmes lignes, .ino) plutôt que de les appeler : ce sont des fonctions
// "static inline" définies plus loin dans le même .ino, un extern non-static
// casserait leur linkage. Ne pas dévier de cette logique sans mettre à jour
// les deux copies en même temps.
extern float    g_cal_fio2;
extern uint16_t g_cal_mbar;
extern bool     g_ble_calib_armed;
extern uint32_t g_ble_calib_arm_ms;
extern bool     g_ble_calib_trigger;
#define BLE_CALIB_ARM_WINDOW_MS 10000
float _ble_c1_mv = 0.0f;   // mis à jour dans loop() juste avant bleUpdateSensors()
float _ble_c2_mv = 0.0f;

// ── UUIDs — HEX UNIQUEMENT (0-9, A-F) ───────────────────────────────────
// ⚠️ Le premier essai utilisait "12340000-FRED-..." → NimBLE a parsé "FRED"
// comme hex, planté silencieusement, produit un UUID corrompu. Ne JAMAIS
// remettre de lettres hors A-F dans ces chaînes.
// NB : 12340001 (HUD), 12340003 (VOTE), 12340005 (ALT) et 1234000A (AGES)
// existaient en v4.4.0, retirés en v4.5.0 — volontairement PAS réutilisés
// pour éviter toute confusion si un vieux dump BLE traîne quelque part.
#define BLE_SVC    "12340000-0000-0000-0000-000000000000"
#define BLE_FIO2   "12340002-0000-0000-0000-000000000000"   // R/W  uint16   2000-10000  FiO2 ×10000
#define BLE_BRIT   "12340004-0000-0000-0000-000000000000"   // R/W  uint8    0-100    luminosité écran %
#define BLE_BATT   "12340006-0000-0000-0000-000000000000"   // R/N  uint8+uint16 batterie % + volts×100 (LE)
#define BLE_CELL   "12340007-0000-0000-0000-000000000000"   // R/N  int16[2]          mV×10 C1, mV×10 C2 (1 déc.)
#define BLE_CALIB  "12340008-0000-0000-0000-000000000000"   // R    uint8             bit0=C1 calib, bit1=C2 calib
#define BLE_RESET  "12340009-0000-0000-0000-000000000000"   // W    uint8    0xAA     reset FiO2+luminosités
#define BLE_HUDBRT "1234000B-0000-0000-0000-000000000000"   // R/W  uint8    0-100    luminosité LED HUD % (v4.5.0)
#define BLE_MBAR   "1234000C-0000-0000-0000-000000000000"   // R/W  uint16   700-1080 pression calib. mbar (v5.7.0)
#define BLE_CALTRIG "1234000D-0000-0000-0000-000000000000"  // W    uint8    0x5A=ARM puis 0xA5=GO <10s → calib (v5.14.3)

// Pointeurs caractéristiques temps réel (notify) — nullptr si BLE non actif
static NimBLECharacteristic* _pBatt   = nullptr;
static NimBLECharacteristic* _pCellMv = nullptr;
static NimBLECharacteristic* _pCalib  = nullptr;
static NimBLECharacteristic* _pBrit   = nullptr;   // v5.14.3 — resync après reset
static NimBLECharacteristic* _pHudBrt = nullptr;   // idem
static NimBLECharacteristic* _pFio2   = nullptr;   // v5.14.3 — idem, oublié en 5.14.3

// ── Callbacks d'écriture ─────────────────────────────────────────────────
// Signature NimBLE v2.x confirmée par compilation réelle : onWrite(p, i).
// ⚠️ L'ancienne signature à 1 paramètre donne "marked 'override', but does
// not override" — ne JAMAIS retirer le NimBLEConnInfo&.
class CbFio2 : public NimBLECharacteristicCallbacks {
    void onWrite(NimBLECharacteristic* p, NimBLEConnInfo& i) override {
        if (p->getValue().length() < 2) return;
        uint16_t v; memcpy(&v, p->getValue().data(), 2);
        if (v >= 2000 && v <= 10000) {
            g_fio2_ref = v / 10000.0f;
            // Persistée tout de suite dans la MÊME clé que calibLoad() relit
            // au boot ("gfred"/"fio2") : le verrou FiO2 déjà en place invalide
            // la calibration au prochain démarrage si besoin.
            prefs.begin("gfred", false);
            prefs.putFloat("fio2", g_fio2_ref);
            prefs.end();
        }
    }
};

// ── Pression de calibration (v5.7.0) ────────────────────────────────────
// Même mécanique EXACTE que CbFio2 : écriture immédiate dans la clé NVS que
// calibLoad() relit au boot, et c'est le verrou pression (calibLoad) qui
// invalidera la calibration si la valeur a changé. On ne touche donc JAMAIS
// à cal1/cal2 ici — une écriture BLE ne doit pas pouvoir effacer une
// calibration en direct pendant que la machine est sur le dos de Fred.
// Valeur canonique = le "NOW" lu sur la ligne "Pressure mBar" du Shearwater.
class CbMbar : public NimBLECharacteristicCallbacks {
    void onWrite(NimBLECharacteristic* p, NimBLEConnInfo& i) override {
        if (p->getValue().length() < 2) return;
        uint16_t v; memcpy(&v, p->getValue().data(), 2);
        if (v >= MBAR_MIN && v <= MBAR_MAX) {
            g_mbar_ref = v;
            prefs.begin("gfred", false);
            prefs.putUShort("mbar", g_mbar_ref);
            prefs.end();
        }
    }
};

// ── Lot 4 — CALIBRER distant (v5.14.3) ──────────────────────────────────
// Double confirmation dans le protocole lui-même (pas juste côté appli) :
// ARM (0x5A) arme une fenêtre de 10s, GO (0xA5) doit arriver dans cette
// fenêtre pour réellement lancer showScreenCA1CA2() (voir loop(), .ino).
// Toute autre valeur, ou GO hors fenêtre, désarme sans rien déclencher.
class CbCalTrig : public NimBLECharacteristicCallbacks {
    void onWrite(NimBLECharacteristic* p, NimBLEConnInfo& i) override {
        if (p->getValue().length() < 1) return;
        uint8_t v = p->getValue()[0];
        if (v == 0x5A) {
            g_ble_calib_armed  = true;
            g_ble_calib_arm_ms = millis();
        } else if (v == 0xA5 && g_ble_calib_armed &&
                   (millis() - g_ble_calib_arm_ms) < BLE_CALIB_ARM_WINDOW_MS) {
            g_ble_calib_trigger = true;   // consommé dans loop()
            g_ble_calib_armed   = false;
        } else {
            g_ble_calib_armed = false;
        }
    }
};

class CbBright : public NimBLECharacteristicCallbacks {
    void onWrite(NimBLECharacteristic* p, NimBLEConnInfo& i) override {
        if (p->getValue().length() < 1) return;
        uint8_t v = p->getValue()[0];
        if (v <= 100) { g_brightness = v; g_params_changed = true; }
    }
};

class CbHudBright : public NimBLECharacteristicCallbacks {
    void onWrite(NimBLECharacteristic* p, NimBLEConnInfo& i) override {
        if (p->getValue().length() < 1) return;
        uint8_t v = p->getValue()[0];
        if (v <= 100) { g_hud_brightness = v; g_params_changed = true; }
    }
};

class CbReset : public NimBLECharacteristicCallbacks {
    void onWrite(NimBLECharacteristic* p, NimBLEConnInfo& i) override {
        if (p->getValue().length() >= 1 && p->getValue()[0] == 0xAA) {
            gfredResetDefaults();
            // v5.14.3 — sans ça, une lecture BLE juste après reset (readAll()
            // côté PWA) renvoyait l'ANCIENNE valeur : gfredResetDefaults()
            // change g_brightness/g_hud_brightness en mémoire/NVS, mais rien
            // ne poussait la nouvelle valeur dans la caractéristique GATT
            // elle-même (setValue() n'avait été appelé qu'une fois, au boot).
            if (_pBrit)   _pBrit->setValue(&g_brightness, 1);
            if (_pHudBrt) _pHudBrt->setValue(&g_hud_brightness, 1);
            if (_pFio2)   { uint16_t fv = (uint16_t)(g_fio2_ref * 10000.0f); _pFio2->setValue(fv); }
        }
    }
};

// ── Connexion — pilote g_ble_up (indicateur BTH bas d'E4, drawE4Frame) ──
// Signature NimBLEServerCallbacks non revalidée par compilation réelle
// comme le reste de ce fichier : à surveiller en premier si erreur ici.
class CbServer : public NimBLEServerCallbacks {
    void onConnect(NimBLEServer* s, NimBLEConnInfo& i) override {
        g_ble_up = true;
    }
    void onDisconnect(NimBLEServer* s, NimBLEConnInfo& i, int reason) override {
        g_ble_up = false;
        NimBLEDevice::startAdvertising();   // NimBLE ne redémarre pas l'advertising seul
    }
};

// ── bleInit() — appelée une fois depuis initBLE(), juste après WiFi.begin()
// et AVANT les splashs (radio RF partagée ESP32-S3). ────────────────────
// Déclaration anticipée — bleInit() appelle bleUpdateSensors() (définie plus
// bas) pour donner une valeur immédiate aux caractéristiques READ/NOTIFY.
inline void bleUpdateSensors();

inline void bleInit() {
    NimBLEDevice::init(OTA_HOSTNAME);   // "GfredDream" — même nom que l'OTA (credentials.h)
    NimBLEDevice::setPower(9);          // valeur int — PAS l'enum ESP_PWR_LVL_P9 (ne compile pas)

    NimBLEServer* srv = NimBLEDevice::createServer();
    srv->setCallbacks(new CbServer());
    NimBLEService* svc = srv->createService(BLE_SVC);

    auto mkRW = [&](const char* u) { return svc->createCharacteristic(u, NIMBLE_PROPERTY::READ | NIMBLE_PROPERTY::WRITE); };
    auto mkW  = [&](const char* u) { return svc->createCharacteristic(u, NIMBLE_PROPERTY::WRITE); };
    auto mkRN = [&](const char* u) { return svc->createCharacteristic(u, NIMBLE_PROPERTY::READ | NIMBLE_PROPERTY::NOTIFY); };

    auto* cF = mkRW(BLE_FIO2);
    uint16_t fv = (uint16_t)(g_fio2_ref * 10000.0f);
    cF->setValue(fv);                                          cF->setCallbacks(new CbFio2());
    _pFio2 = cF;   // v5.14.3 — pour resync depuis CbReset (même bug que brit/hud)
    auto* cM = mkRW(BLE_MBAR);
    uint16_t mv_ = g_mbar_ref;
    cM->setValue(mv_);                                         cM->setCallbacks(new CbMbar());
    mkW(BLE_CALTRIG)->setCallbacks(new CbCalTrig());
    auto* cB = mkRW(BLE_BRIT);  cB->setValue(&g_brightness, 1);       cB->setCallbacks(new CbBright());
    auto* cH = mkRW(BLE_HUDBRT); cH->setValue(&g_hud_brightness, 1);  cH->setCallbacks(new CbHudBright());
    _pBrit   = cB;   // v5.14.3 — pour resync depuis CbReset
    _pHudBrt = cH;
    mkW(BLE_RESET)->setCallbacks(new CbReset());

    _pBatt   = mkRN(BLE_BATT);
    _pCellMv = mkRN(BLE_CELL);
    _pCalib  = mkRN(BLE_CALIB);   // v5.14.3 — passé en NOTIFY, cf. calRefMatch ci-dessous

    // Valeur initiale immédiate — sans ça, ces 3 caractéristiques restent
    // VIDES (0 octet) jusqu'au premier passage de bleUpdateSensors() dans
    // loop() (~1s plus tard). Un client qui se connecte et lit avant ce
    // délai reçoit un DataView vide → plantage côté appli ("Offset is
    // outside the bounds of the DataView"). Fix v4.6.3.
    bleUpdateSensors();

    svc->start();

    NimBLEAdvertising* adv = NimBLEDevice::getAdvertising();
    adv->addServiceUUID(BLE_SVC);
    // v2.x : contrairement à la v1.x, le nom n'est PLUS advertisé par défaut
    // (changelog officiel h2zero : "Advertising the name ... will no longer
    // happen by default and should be set manually ... using
    // NimBLEAdvertising::setName"). C'est ce qui manquait — nRF Connect
    // affichait "N/A" au lieu de "GfredDream" en scan (résolu v4.6.1).
    adv->setName(OTA_HOSTNAME);
    // L'ancien adv->setScanResponse(true) (v1.x) a été renommé
    // enableScanResponse() en v2.x — pas nécessaire ici, setName() suffit
    // à faire apparaître le nom en scan.
    adv->start();

    g_ble_up = false;   // ne passe à true que sur connexion réelle (CbServer::onConnect)
    Serial.println("BLE pret (GfredDream)");
}

// ── bleUpdateSensors() — appelée ~1×/s depuis loop(), proxies déjà à jour
inline void bleUpdateSensors() {
    if (!_pBatt) return;   // BLE non initialisé (radios coupées ou boot faible tension)

    // Batterie : octet 0 = % (uint8), octets 1-2 = volts ×100 (uint16 LE)
    // — demande Fred 12/07 : afficher les volts en plus du %
    uint8_t battBuf[3];
    battBuf[0] = (uint8_t)g_bat_pct;
    uint16_t bv100 = (uint16_t)(g_bat_v * 100.0f);
    battBuf[1] = (uint8_t)(bv100 & 0xFF);
    battBuf[2] = (uint8_t)(bv100 >> 8);
    _pBatt->setValue(battBuf, 3);
    _pBatt->notify();

    // Cellules : mV ×10 (1 décimale, comme à l'écran) au lieu de mV entiers —
    // demande Fred 12/07 : "10.6" pas "10"
    int16_t pair[2] = { (int16_t)lroundf(_ble_c1_mv * 10.0f), (int16_t)lroundf(_ble_c2_mv * 10.0f) };
    _pCellMv->setValue((uint8_t*)pair, 4);
    _pCellMv->notify();

    // v5.14.3 — FIX : le byte calib envoyé en BLE ne vérifiait QUE
    // "une valeur de calib existe" (g_calib_cX > 1.0f), sans jamais tenir
    // compte de calRefMatch() (pression/FiO2 assortis à la calib). Résultat :
    // écrire un mbar/FiO2 différent invalidait bien la calib sur l'ÉCRAN
    // (c1CalOk()/c2CalOk(), .ino) mais les points verts de la PWA restaient
    // allumés indéfiniment, même en relisant. Réplique ICI la même logique
    // que calRefMatch()/c1CalOk()/c2CalOk() (.ino ligne ~524) — si l'une des
    // deux copies change, mettre à jour l'autre.
    bool calRefMatch_ = (g_mbar_ref == g_cal_mbar) &&
                         (fabsf(g_fio2_ref - g_cal_fio2) <= 0.005f);
    uint8_t calib = ((g_calib_c1 > 1.0f && calRefMatch_) ? 0x01 : 0) |
                    ((g_calib_c2 > 1.0f && calRefMatch_) ? 0x02 : 0);
    _pCalib->setValue(&calib, 1);
    _pCalib->notify();   // v5.14.3 — poussé en direct, plus besoin de reconnecter
}

// ── bleStop() — coupe le BLE (verrou tension mid-session, cf. sensorsUpdate())
inline void bleStop() {
    if (_pBatt) {
        NimBLEDevice::deinit(true);
        _pBatt = _pCellMv = _pCalib = _pBrit = _pHudBrt = _pFio2 = nullptr;
    }
    g_ble_up = false;
}
